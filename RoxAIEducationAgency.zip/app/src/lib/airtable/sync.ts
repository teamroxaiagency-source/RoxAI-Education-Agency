import "server-only";

import type { SupabaseClient } from "@supabase/supabase-js";
import { getServerEnv } from "@/lib/env";
import type { Database } from "@/lib/supabase/database.types";

// Talks to the Airtable REST API directly via fetch rather than the
// `airtable` npm package — that package isn't reliably compatible with the
// Cloudflare Workers runtime this app deploys to. The REST API is simple
// enough that the SDK wasn't buying much anyway.

const INQUIRY_ID_FIELD = "RoxAI Inquiry ID";

function airtableUrl(baseId: string, tableName: string, path = ""): string {
  return `https://api.airtable.com/v0/${baseId}/${encodeURIComponent(tableName)}${path}`;
}

/**
 * Pushes an inquiry's current state into RoxAI's own Airtable lead-tracking
 * base — reusing the tool RoxAI already runs on rather than standing up a
 * second system. Per-school base/table is configured in
 * school_integrations; a school with no Airtable configured is a no-op, not
 * an error, so Airtable being unset never blocks the core intake/reply flow.
 */
export async function syncInquiryToAirtable(
  db: SupabaseClient<Database>,
  inquiryId: string,
): Promise<void> {
  const env = getServerEnv();
  if (!env.AIRTABLE_API_KEY) return;

  const { data: inquiry, error: inquiryError } = await db
    .from("inquiries")
    .select("*, schools(name)")
    .eq("id", inquiryId)
    .single();
  if (inquiryError || !inquiry) return;

  const { data: integration } = await db
    .from("school_integrations")
    .select("airtable_base_id, airtable_table_name")
    .eq("school_id", inquiry.school_id)
    .maybeSingle();

  if (!integration?.airtable_base_id || !integration.airtable_table_name) return;

  const { airtable_base_id: baseId, airtable_table_name: tableName } = integration;
  const authHeaders = {
    authorization: `Bearer ${env.AIRTABLE_API_KEY}`,
    "content-type": "application/json",
  };

  const schoolName = (inquiry as unknown as { schools: { name: string } | null }).schools?.name ?? "";

  const fields = {
    [INQUIRY_ID_FIELD]: inquiry.id,
    "Family Name": inquiry.family_name,
    "Student Name": inquiry.student_name ?? "",
    "Family Email": inquiry.family_email ?? "",
    "Family Phone": inquiry.family_phone ?? "",
    "Grade Requested": inquiry.grade_requested,
    Language: inquiry.preferred_language,
    Status: inquiry.status,
    School: schoolName,
    Source: inquiry.source,
    "Last Activity": inquiry.last_activity_at,
  };

  const filterFormula = encodeURIComponent(`{${INQUIRY_ID_FIELD}} = "${inquiry.id}"`);
  const searchResponse = await fetch(
    airtableUrl(baseId, tableName, `?filterByFormula=${filterFormula}&maxRecords=1`),
    { headers: authHeaders },
  );

  if (!searchResponse.ok) {
    console.error("Airtable lookup failed", inquiry.id, searchResponse.status, await searchResponse.text());
    return;
  }

  const { records } = (await searchResponse.json()) as { records: { id: string }[] };

  const writeResponse =
    records.length > 0
      ? await fetch(airtableUrl(baseId, tableName, `/${records[0].id}`), {
          method: "PATCH",
          headers: authHeaders,
          body: JSON.stringify({ fields }),
        })
      : await fetch(airtableUrl(baseId, tableName), {
          method: "POST",
          headers: authHeaders,
          body: JSON.stringify({ records: [{ fields }] }),
        });

  if (!writeResponse.ok) {
    console.error("Airtable write failed", inquiry.id, writeResponse.status, await writeResponse.text());
  }
}
