import "server-only";

import { callAnthropicText } from "@/lib/ai/anthropic";
import { LANGUAGE_NAMES } from "@/lib/i18n/language";
import type { PreferredLanguage } from "@/lib/supabase/database.types";

/**
 * Translates a staff-written reply into the family's preferred language
 * before it goes out, so an ongoing conversation doesn't drift back to
 * English just because that's what staff type in. Returns null (never
 * throws) when no Anthropic key is configured — callers should send the
 * original text and let staff know via the UI, rather than blocking send.
 */
export async function translateForFamily(
  text: string,
  targetLanguage: PreferredLanguage,
): Promise<string | null> {
  if (targetLanguage === "en") return null; // staff already write in English by default

  const languageName = LANGUAGE_NAMES[targetLanguage];
  const translated = await callAnthropicText({
    system:
      `Translate the following school-admissions email into ${languageName}. Preserve the meaning and tone ` +
      "exactly — don't add, remove, or soften anything. Output only the translated text, no commentary, no quotes.",
    userMessage: text,
  });

  return translated?.trim() || null;
}
