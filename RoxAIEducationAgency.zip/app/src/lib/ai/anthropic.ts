import "server-only";

import { getServerEnv } from "@/lib/env";

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_VERSION = "2023-06-01";
const MODEL = "claude-sonnet-5";

type ToolDefinition = {
  name: string;
  description: string;
  input_schema: Record<string, unknown>;
};

/** Returns null (rather than throwing) when no key is configured, so callers can fall back. */
function getApiKey(): string | null {
  return getServerEnv().ANTHROPIC_API_KEY ?? null;
}

/**
 * Calls Claude with a single forced tool use, and returns the tool's
 * validated input. Used for structured extraction where we need the model
 * constrained to a strict JSON shape (e.g. grade_requested limited to the
 * school's actual configured grade levels) rather than free text.
 */
export async function callAnthropicTool<T>(params: {
  system: string;
  userMessage: string;
  tool: ToolDefinition;
}): Promise<T | null> {
  const apiKey = getApiKey();
  if (!apiKey) return null;

  const response = await fetch(ANTHROPIC_API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": ANTHROPIC_VERSION,
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1024,
      system: params.system,
      messages: [{ role: "user", content: params.userMessage }],
      tools: [params.tool],
      tool_choice: { type: "tool", name: params.tool.name },
    }),
  });

  if (!response.ok) {
    console.error("Anthropic tool call failed", response.status, await response.text());
    return null;
  }

  const data = await response.json();
  const toolUse = (data.content as Array<Record<string, unknown>>)?.find((b) => b.type === "tool_use");
  return (toolUse?.input as T) ?? null;
}

/** Plain-text completion, used for reply drafting. */
export async function callAnthropicText(params: { system: string; userMessage: string }): Promise<string | null> {
  const apiKey = getApiKey();
  if (!apiKey) return null;

  const response = await fetch(ANTHROPIC_API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": ANTHROPIC_VERSION,
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1024,
      system: params.system,
      messages: [{ role: "user", content: params.userMessage }],
    }),
  });

  if (!response.ok) {
    console.error("Anthropic text call failed", response.status, await response.text());
    return null;
  }

  const data = await response.json();
  const textBlock = (data.content as Array<{ type: string; text?: string }>)?.find((b) => b.type === "text");
  return textBlock?.text ?? null;
}
