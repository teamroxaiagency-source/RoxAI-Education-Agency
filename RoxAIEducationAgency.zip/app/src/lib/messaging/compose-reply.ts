import { callAnthropicText } from "@/lib/ai/anthropic";
import type { AvailabilityStatus } from "@/lib/availability";
import { buildBookingUrl } from "@/lib/booking-token";
import { LANGUAGE_NAMES } from "@/lib/i18n/language";
import type { PreferredLanguage } from "@/lib/supabase/database.types";

export interface ComposeReplyInput {
  schoolName: string;
  familyName: string;
  studentName: string | null;
  gradeRequested: string;
  /** null when the requested grade isn't one the school has configured availability for yet. */
  availability: AvailabilityStatus | null;
  inquiryId: string;
  language: PreferredLanguage;
}

export interface ComposedReply {
  subject: string;
  textBody: string;
}

/**
 * Drafts the same-day acknowledgement email, in the family's own language
 * (`language` is detected from their inbound message — see
 * src/lib/intake/extract-inquiry-fields.ts). Every fact in the reply
 * (seats available, grade, next step) is computed here from real data
 * *before* any AI call — the AI, when configured, is only allowed to
 * improve the wording, never to introduce a new claim, because the facts
 * are handed to it as fixed bullet points it's instructed to preserve
 * verbatim in meaning. Without an API key, the deterministic template below
 * is what ships — it is not a canned response either, since every field in
 * it is this family's real data, not boilerplate, and it's still fully
 * translated (English/Swahili/French), not just left in English.
 */
export async function composeSameDayReply(input: ComposeReplyInput): Promise<ComposedReply> {
  const facts = buildFacts(input);
  const template = renderTemplate(input);

  const languageName = LANGUAGE_NAMES[input.language];
  const aiText = await callAnthropicText({
    system:
      `You are drafting a warm, concise same-day acknowledgement email, entirely in ${languageName}, from a ` +
      "school's admissions team to a prospective family, on behalf of the RoxAI Inquiry-to-Enrollment Agent. " +
      "You will be given a list of FACTS that are all true and already verified — restate them faithfully, in " +
      `your own words, but NEVER add a fact that isn't listed (no invented seat counts, dates, prices, or ` +
      `promises), and never switch languages even if the facts below are written in English. Keep it under 150 ` +
      "words, warm but professional, and end with the exact next-step call to action given in the facts. Output " +
      `only the email body text in ${languageName}, no subject line, no signature block beyond a simple sign-off ` +
      `from "${input.schoolName}".`,
    userMessage: `FACTS:\n${facts.map((f) => `- ${f}`).join("\n")}`,
  });

  return {
    subject: template.subject,
    textBody: aiText?.trim() || template.textBody,
  };
}

function buildFacts(input: ComposeReplyInput): string[] {
  const facts = [
    `Family/parent name: ${input.familyName}`,
    `School: ${input.schoolName}`,
    `Grade requested: ${input.gradeRequested}`,
  ];
  if (input.studentName) facts.push(`Student's first name: ${input.studentName}`);

  if (input.availability === null) {
    facts.push(
      "We don't yet have a confirmed open-seat count on file for this exact grade, so admissions staff will personally confirm availability and follow up within one business day.",
    );
  } else if (input.availability.hasSpace) {
    facts.push(
      `There are currently ${input.availability.seatsAvailable} open seat(s) in ${input.availability.gradeLevel}.`,
    );
    facts.push(`Next step: book a tour or call at ${buildBookingUrl(input.inquiryId)}`);
  } else {
    facts.push(`${input.availability.gradeLevel} is currently full (0 open seats).`);
    facts.push("Next step: we've added the family to the waitlist and admissions staff will reach out if a seat opens.");
  }

  return facts;
}

interface Translations {
  subject: (schoolName: string, studentName: string | null) => string;
  greeting: (firstName: string) => string;
  thanks: (schoolName: string) => string;
  hasSpace: (seatsAvailable: number, gradeLevel: string) => string;
  bookingCta: (link: string) => string;
  full: (gradeLevel: string) => string;
  unknown: (gradeRequested: string) => string;
  signOff: (schoolName: string) => string;
}

const TRANSLATIONS: Record<PreferredLanguage, Translations> = {
  en: {
    subject: (schoolName, studentName) => `Re: Your inquiry to ${schoolName}${studentName ? ` for ${studentName}` : ""}`,
    greeting: (firstName) => `Hi ${firstName},`,
    thanks: (schoolName) => `Thank you for reaching out to ${schoolName}!`,
    hasSpace: (seatsAvailable, gradeLevel) =>
      `Good news — we currently have ${seatsAvailable} open seat${seatsAvailable === 1 ? "" : "s"} in ${gradeLevel}.`,
    bookingCta: (link) => `You can pick a tour or call time that works for you here: ${link}`,
    full: (gradeLevel) =>
      `${gradeLevel} is fully enrolled at the moment, so we've added you to our waitlist. Our admissions team will reach out as soon as a seat opens up.`,
    unknown: (gradeRequested) =>
      `We've logged your inquiry for ${gradeRequested}. Our admissions team is confirming current availability for this grade and will follow up with you within one business day.`,
    signOff: (schoolName) => `${schoolName} Admissions`,
  },
  sw: {
    subject: (schoolName, studentName) =>
      `Kuhusu: Ombi lako la udahili katika ${schoolName}${studentName ? ` kwa ajili ya ${studentName}` : ""}`,
    greeting: (firstName) => `Habari ${firstName},`,
    thanks: (schoolName) => `Asante kwa kuwasiliana na ${schoolName}!`,
    hasSpace: (seatsAvailable, gradeLevel) =>
      `Habari njema — kwa sasa tuna nafasi ${seatsAvailable} katika ${gradeLevel}.`,
    bookingCta: (link) => `Unaweza kuchagua muda wa ziara au simu unaokufaa hapa: ${link}`,
    full: (gradeLevel) =>
      `${gradeLevel} kwa sasa imejaa nafasi zote, hivyo tumekuweka kwenye orodha ya kusubiri. Timu yetu ya udahili itawasiliana nawe mara nafasi itakapopatikana.`,
    unknown: (gradeRequested) =>
      `Tumepokea ombi lako kwa ajili ya ${gradeRequested}. Timu yetu ya udahili inathibitisha nafasi zilizopo kwa sasa na itawasiliana nawe ndani ya siku moja ya kazi.`,
    signOff: (schoolName) => `Idara ya Udahili — ${schoolName}`,
  },
  fr: {
    subject: (schoolName, studentName) =>
      `Votre demande d'inscription à ${schoolName}${studentName ? ` pour ${studentName}` : ""}`,
    greeting: (firstName) => `Bonjour ${firstName},`,
    thanks: (schoolName) => `Merci de nous avoir contactés à ${schoolName} !`,
    hasSpace: (seatsAvailable, gradeLevel) =>
      `Bonne nouvelle — nous avons actuellement ${seatsAvailable} place${seatsAvailable === 1 ? "" : "s"} disponible${seatsAvailable === 1 ? "" : "s"} en ${gradeLevel}.`,
    bookingCta: (link) => `Vous pouvez choisir un horaire de visite ou d'appel qui vous convient ici : ${link}`,
    full: (gradeLevel) =>
      `${gradeLevel} est actuellement complet. Nous vous avons donc ajouté à notre liste d'attente. Notre équipe des admissions vous contactera dès qu'une place se libère.`,
    unknown: (gradeRequested) =>
      `Nous avons enregistré votre demande pour ${gradeRequested}. Notre équipe des admissions confirme la disponibilité actuelle pour ce niveau et vous recontactera sous un jour ouvré.`,
    signOff: (schoolName) => `L'équipe des admissions de ${schoolName}`,
  },
};

function renderTemplate(input: ComposeReplyInput): ComposedReply {
  const t = TRANSLATIONS[input.language];
  const greetingName = input.familyName.split(" ")[0] || input.familyName;

  const lines = [t.greeting(greetingName), "", t.thanks(input.schoolName)];

  if (input.availability === null) {
    lines.push(t.unknown(input.gradeRequested));
  } else if (input.availability.hasSpace) {
    lines.push(t.hasSpace(input.availability.seatsAvailable, input.availability.gradeLevel));
    lines.push(t.bookingCta(buildBookingUrl(input.inquiryId)));
  } else {
    lines.push(t.full(input.availability.gradeLevel));
  }

  lines.push("", t.signOff(input.schoolName));

  return { subject: t.subject(input.schoolName, input.studentName), textBody: lines.join("\n") };
}
