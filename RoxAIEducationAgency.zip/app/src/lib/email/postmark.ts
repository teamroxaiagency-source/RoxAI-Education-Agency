import "server-only";

import { getServerEnv } from "@/lib/env";

const POSTMARK_SEND_URL = "https://api.postmarkapp.com/email";

export interface SendEmailParams {
  to: string;
  subject: string;
  textBody: string;
  replyTo?: string;
  /** Threads the reply under the original inbound message in mail clients. */
  inReplyTo?: string;
}

export interface SendEmailResult {
  messageId: string;
}

/** Sends via Postmark's transactional API. Throws on failure — callers decide how to handle/retry. */
export async function sendEmail(params: SendEmailParams): Promise<SendEmailResult> {
  const env = getServerEnv();

  const headers: Array<{ Name: string; Value: string }> = [];
  if (params.inReplyTo) {
    headers.push({ Name: "In-Reply-To", Value: params.inReplyTo });
    headers.push({ Name: "References", Value: params.inReplyTo });
  }

  const response = await fetch(POSTMARK_SEND_URL, {
    method: "POST",
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      "x-postmark-server-token": env.POSTMARK_SERVER_TOKEN,
    },
    body: JSON.stringify({
      From: env.POSTMARK_FROM_EMAIL,
      To: params.to,
      ReplyTo: params.replyTo,
      Subject: params.subject,
      TextBody: params.textBody,
      Headers: headers,
      MessageStream: "outbound",
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Postmark send failed (${response.status}): ${body}`);
  }

  const data = (await response.json()) as { MessageID: string };
  return { messageId: data.MessageID };
}

/**
 * Shape of Postmark's Inbound webhook payload — trimmed to the fields we
 * actually use. See https://postmarkapp.com/developer/webhooks/inbound-webhook
 */
export interface PostmarkInboundPayload {
  MessageID: string;
  From: string;
  FromName: string;
  FromFull: { Email: string; Name: string };
  To: string;
  OriginalRecipient: string;
  Subject: string;
  TextBody: string;
  StrippedTextReply?: string;
  Date: string;
}
