import type { PreferredLanguage } from "@/lib/supabase/database.types";

export const SUPPORTED_LANGUAGES: PreferredLanguage[] = ["en", "sw", "fr"];

export const LANGUAGE_NAMES: Record<PreferredLanguage, string> = {
  en: "English",
  sw: "Swahili",
  fr: "French",
};

/** BCP 47 locale for date/time formatting (Intl.DateTimeFormat). */
export const LANGUAGE_LOCALES: Record<PreferredLanguage, string> = {
  en: "en-US",
  sw: "sw-KE",
  fr: "fr-FR",
};

// A handful of high-frequency, low-ambiguity words per language — enough to
// tell Swahili/French from English in a short inquiry email without needing
// a real language-detection library. Deliberately conservative: ties and
// low signal fall back to English rather than guessing.
const SWAHILI_MARKERS = [
  "habari", "mtoto", "shule", "asante", "karibu", "nafasi", "mwanafunzi",
  "darasa", "ningependa", "naomba", "mzazi", "jina", "tafadhali", "ndiyo",
  "salamu", "elimu", "usajili",
];
const FRENCH_MARKERS = [
  "bonjour", "merci", "école", "ecole", "enfant", "élève", "eleve", "classe",
  "inscription", "je voudrais", "s'il vous plaît", "svp", "cordialement",
  "madame", "monsieur", "disponibilité", "disponibilite",
];

function countMatches(haystack: string, markers: string[]): number {
  let count = 0;
  for (const marker of markers) {
    if (haystack.includes(marker)) count++;
  }
  return count;
}

/**
 * Best-effort language guess from free text, used when no Anthropic key is
 * configured (see extract-inquiry-fields.ts, which prefers Claude's
 * judgment when available). Two-word minimum margin avoids flip-flopping
 * on a single shared/ambiguous word.
 */
export function detectLanguageHeuristically(text: string): PreferredLanguage {
  const normalized = text.toLowerCase();
  const swahiliScore = countMatches(normalized, SWAHILI_MARKERS);
  const frenchScore = countMatches(normalized, FRENCH_MARKERS);

  if (swahiliScore >= 2 && swahiliScore > frenchScore) return "sw";
  if (frenchScore >= 2 && frenchScore > swahiliScore) return "fr";
  return "en";
}

export function isPreferredLanguage(value: string): value is PreferredLanguage {
  return (SUPPORTED_LANGUAGES as string[]).includes(value);
}
