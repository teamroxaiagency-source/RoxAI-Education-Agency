import type { PreferredLanguage } from "@/lib/supabase/database.types";

export interface BookingStrings {
  invalidLinkTitle: string;
  invalidLinkBody: string;
  notFoundTitle: string;
  notFoundBody: string;
  alreadyScheduledTitle: string;
  alreadyScheduledBody: (schoolName: string) => string;
  expiredTitle: string;
  expiredBody: string;
  pageTitle: (schoolName: string) => string;
  forLine: (familyName: string, studentName: string | null, grade: string) => string;
  noSlots: string;
  bookedConfirmation: string;
  genericError: string;
}

export const BOOKING_STRINGS: Record<PreferredLanguage, BookingStrings> = {
  en: {
    invalidLinkTitle: "This link isn't valid",
    invalidLinkBody: "It may have expired. Please contact the school directly.",
    notFoundTitle: "Inquiry not found",
    notFoundBody: "Please contact the school directly.",
    alreadyScheduledTitle: "You're already scheduled",
    alreadyScheduledBody: (schoolName) =>
      `${schoolName} admissions already has a booking on file for you. Check your email for the calendar invite, or contact the school if you need to reschedule.`,
    expiredTitle: "This link has expired",
    expiredBody: "Please contact the school directly to re-open your inquiry.",
    pageTitle: (schoolName) => `Book a tour or call with ${schoolName}`,
    forLine: (familyName, studentName, grade) => `For ${familyName}${studentName ? ` · ${studentName}` : ""} · ${grade}`,
    noSlots: "No open times right now — our admissions team will reach out directly to schedule.",
    bookedConfirmation: "You're booked! A calendar invite is on its way to your email.",
    genericError: "Booking failed",
  },
  sw: {
    invalidLinkTitle: "Kiungo hiki si sahihi",
    invalidLinkBody: "Huenda kimekwisha muda wake. Tafadhali wasiliana na shule moja kwa moja.",
    notFoundTitle: "Ombi halikupatikana",
    notFoundBody: "Tafadhali wasiliana na shule moja kwa moja.",
    alreadyScheduledTitle: "Tayari umepangiwa muda",
    alreadyScheduledBody: (schoolName) =>
      `Idara ya udahili ya ${schoolName} tayari ina miadi yako. Angalia barua pepe yako kwa mwaliko wa kalenda, au wasiliana na shule ikiwa unahitaji kubadilisha muda.`,
    expiredTitle: "Kiungo hiki kimekwisha muda wake",
    expiredBody: "Tafadhali wasiliana na shule moja kwa moja ili kufungua tena ombi lako.",
    pageTitle: (schoolName) => `Panga ziara au simu na ${schoolName}`,
    forLine: (familyName, studentName, grade) => `Kwa ajili ya ${familyName}${studentName ? ` · ${studentName}` : ""} · ${grade}`,
    noSlots: "Hakuna muda ulio wazi kwa sasa — timu yetu ya udahili itawasiliana nawe moja kwa moja kupanga muda.",
    bookedConfirmation: "Umepangiwa muda! Mwaliko wa kalenda unakuja kwenye barua pepe yako.",
    genericError: "Kupanga muda hakukufaulu",
  },
  fr: {
    invalidLinkTitle: "Ce lien n'est pas valide",
    invalidLinkBody: "Il a peut-être expiré. Veuillez contacter directement l'école.",
    notFoundTitle: "Demande introuvable",
    notFoundBody: "Veuillez contacter directement l'école.",
    alreadyScheduledTitle: "Vous avez déjà un rendez-vous",
    alreadyScheduledBody: (schoolName) =>
      `Le service des admissions de ${schoolName} a déjà une réservation à votre nom. Consultez votre email pour l'invitation calendrier, ou contactez l'école si vous devez reprogrammer.`,
    expiredTitle: "Ce lien a expiré",
    expiredBody: "Veuillez contacter directement l'école pour rouvrir votre demande.",
    pageTitle: (schoolName) => `Réservez une visite ou un appel avec ${schoolName}`,
    forLine: (familyName, studentName, grade) => `Pour ${familyName}${studentName ? ` · ${studentName}` : ""} · ${grade}`,
    noSlots: "Aucun créneau disponible pour le moment — notre équipe des admissions vous contactera directement pour planifier.",
    bookedConfirmation: "C'est réservé ! Une invitation calendrier arrive dans votre email.",
    genericError: "Échec de la réservation",
  },
};
