import "server-only";

import type { SupabaseClient } from "@supabase/supabase-js";
import type { AuditActorType, Database } from "@/lib/supabase/database.types";

/**
 * Records one automated-action entry. Called from trusted server code
 * (webhooks, calendar sync, cron) using the admin/service-role client —
 * client-side staff sessions can never write here (see RLS policies), so
 * every row through this path is genuinely something the system/agent did,
 * not something a browser claimed it did.
 */
export async function logAudit(
  db: SupabaseClient<Database>,
  entry: {
    schoolId: string;
    inquiryId?: string;
    actorType: AuditActorType;
    actorId?: string;
    action: string;
    detail?: Record<string, unknown>;
  },
): Promise<void> {
  const { error } = await db.from("audit_log").insert({
    school_id: entry.schoolId,
    inquiry_id: entry.inquiryId ?? null,
    actor_type: entry.actorType,
    actor_id: entry.actorId ?? null,
    action: entry.action,
    detail: entry.detail ?? {},
  });

  if (error) {
    console.error("Failed to write audit_log entry", entry.action, error);
  }
}
