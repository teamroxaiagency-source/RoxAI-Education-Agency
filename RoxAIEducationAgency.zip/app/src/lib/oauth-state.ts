import "server-only";

import { createHmac, timingSafeEqual } from "node:crypto";
import { getServerEnv } from "@/lib/env";

interface OAuthState {
  schoolId: string;
  staffId: string;
  issuedAt: number;
}

const MAX_AGE_MS = 10 * 60 * 1000; // the OAuth round-trip should take seconds, not minutes

function sign(payload: string): string {
  const env = getServerEnv();
  return createHmac("sha256", `${env.ENCRYPTION_KEY}:oauth-state`).update(payload).digest("base64url");
}

/** Prevents a forged `state` param from linking a stolen Google auth code to an arbitrary school. */
export function encodeOAuthState(state: Omit<OAuthState, "issuedAt">): string {
  const payload = JSON.stringify({ ...state, issuedAt: Date.now() });
  const encodedPayload = Buffer.from(payload).toString("base64url");
  return `${encodedPayload}.${sign(encodedPayload)}`;
}

export function decodeOAuthState(state: string): OAuthState | null {
  const [encodedPayload, signature] = state.split(".");
  if (!encodedPayload || !signature) return null;

  const expected = Buffer.from(sign(encodedPayload));
  const actual = Buffer.from(signature);
  if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) return null;

  try {
    const parsed = JSON.parse(Buffer.from(encodedPayload, "base64url").toString("utf8")) as OAuthState;
    if (Date.now() - parsed.issuedAt > MAX_AGE_MS) return null;
    return parsed;
  } catch {
    return null;
  }
}
