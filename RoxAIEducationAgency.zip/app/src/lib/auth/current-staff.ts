import "server-only";

import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import type { Database } from "@/lib/supabase/database.types";

type StaffRow = Database["public"]["Tables"]["staff_users"]["Row"];

/**
 * Resolves the signed-in staff member's own row (RLS-scoped, so this can
 * only ever be their own school's staff_users row) or redirects to /login.
 * Use this at the top of any protected page/action instead of trusting
 * proxy.ts alone — proxy only checks "is there a session", this checks
 * "is there a real, active staff_users row for that session".
 */
export async function requireCurrentStaff(): Promise<StaffRow> {
  const supabase = await createServerSupabaseClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: staff, error } = await supabase
    .from("staff_users")
    .select("*")
    .eq("id", user.id)
    .eq("active", true)
    .maybeSingle();

  if (error || !staff) {
    redirect("/login");
  }

  return staff;
}
