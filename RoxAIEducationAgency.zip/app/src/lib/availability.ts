import "server-only";

import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/lib/supabase/database.types";

export interface AvailabilityStatus {
  gradeLevel: string;
  capacityTotal: number;
  seatsTaken: number;
  seatsAvailable: number;
  hasSpace: boolean;
}

/**
 * The one source of truth the agent is allowed to draft a reply from.
 * Returns null when the school has no availability row configured for this
 * grade yet — the caller must never fabricate a seat count in that case.
 */
export async function checkAvailability(
  db: SupabaseClient<Database>,
  schoolId: string,
  gradeLevel: string,
): Promise<AvailabilityStatus | null> {
  const { data, error } = await db
    .from("availability")
    .select("grade_level, capacity_total, seats_taken")
    .eq("school_id", schoolId)
    .eq("grade_level", gradeLevel)
    .maybeSingle();

  if (error || !data) return null;

  const seatsAvailable = Math.max(data.capacity_total - data.seats_taken, 0);
  return {
    gradeLevel: data.grade_level,
    capacityTotal: data.capacity_total,
    seatsTaken: data.seats_taken,
    seatsAvailable,
    hasSpace: seatsAvailable > 0,
  };
}
