import "server-only";

import { createHmac, timingSafeEqual } from "node:crypto";
import { getServerEnv } from "@/lib/env";

/**
 * The tour/call booking page is reachable without a staff login (the
 * family clicks a link from an email), so it's guarded by an HMAC token
 * over the inquiry id rather than by auth — this makes the booking link
 * single-purpose and unguessable even though inquiry ids themselves are
 * only-moderately-secret UUIDs.
 */
function sign(inquiryId: string): string {
  const env = getServerEnv();
  return createHmac("sha256", `${env.ENCRYPTION_KEY}:booking`).update(inquiryId).digest("base64url");
}

export function createBookingToken(inquiryId: string): string {
  return sign(inquiryId);
}

export function verifyBookingToken(inquiryId: string, token: string): boolean {
  const expected = Buffer.from(sign(inquiryId));
  const actual = Buffer.from(token);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export function buildBookingUrl(inquiryId: string): string {
  const env = getServerEnv();
  const token = createBookingToken(inquiryId);
  return `${env.APP_BASE_URL}/book/${inquiryId}?t=${token}`;
}
