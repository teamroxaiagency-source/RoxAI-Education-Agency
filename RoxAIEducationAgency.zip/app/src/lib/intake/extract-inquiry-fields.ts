import { callAnthropicTool } from "@/lib/ai/anthropic";
import { matchGradeLevel } from "@/lib/validation/grade";
import { normalizePhoneToE164 } from "@/lib/validation/phone";
import { detectLanguageHeuristically, isPreferredLanguage, SUPPORTED_LANGUAGES } from "@/lib/i18n/language";
import type { PreferredLanguage } from "@/lib/supabase/database.types";

export interface ExtractedInquiryFields {
  familyName: string;
  studentName: string | null;
  /** Exact match against school.grade_levels — the only value availability lookups may trust. */
  matchedGradeLevel: string | null;
  /** What the family actually wrote, for staff display even when unmatched. Always non-empty. */
  gradeRequestedRaw: string;
  phone: string | null; // E.164
  /** Language the family wrote in — drives the same-day reply and booking page language. */
  language: PreferredLanguage;
}

interface ExtractInput {
  fromName: string | null;
  fromEmail: string;
  subject: string;
  bodyText: string;
  schoolGradeLevels: string[];
}

const UNSPECIFIED = "unspecified";

export async function extractInquiryFields(input: ExtractInput): Promise<ExtractedInquiryFields> {
  const aiResult = await extractWithClaude(input);
  if (aiResult) return aiResult;
  return extractHeuristically(input);
}

async function extractWithClaude(input: ExtractInput): Promise<ExtractedInquiryFields | null> {
  const gradeEnum = [...input.schoolGradeLevels, UNSPECIFIED];

  const result = await callAnthropicTool<{
    family_name: string;
    student_name?: string;
    grade_requested: string;
    grade_requested_raw_text?: string;
    phone_number?: string;
    language: PreferredLanguage;
  }>({
    system:
      "You extract structured admissions-inquiry fields from a family's inbound email to a school. " +
      "Only use information actually present in the email — never invent a name, grade, or phone number. " +
      "grade_requested MUST be exactly one of the allowed values given in the tool schema; if the email " +
      `does not clearly state a grade the school actually offers, use "${UNSPECIFIED}". ` +
      "Also identify the language the email itself is written in, so the reply can match it.",
    userMessage:
      `From: ${input.fromName ?? "(no display name)"} <${input.fromEmail}>\n` +
      `Subject: ${input.subject}\n\n${input.bodyText}`,
    tool: {
      name: "extract_inquiry_fields",
      description: "Extracts family name, student name, requested grade, and phone number from an admissions inquiry email.",
      input_schema: {
        type: "object",
        properties: {
          family_name: {
            type: "string",
            description: "The parent/guardian's name. Fall back to a reasonable guess from the email signature or display name if not explicitly stated.",
          },
          student_name: {
            type: "string",
            description: "The prospective student's first name, if mentioned. Omit if not mentioned.",
          },
          grade_requested: {
            type: "string",
            enum: gradeEnum,
            description: "The grade level requested, matched exactly to one of the school's offered grades.",
          },
          grade_requested_raw_text: {
            type: "string",
            description: "The grade as the family actually wrote it (e.g. '5th grade', 'K'), even if it doesn't match an offered grade. Omit if no grade was mentioned at all.",
          },
          phone_number: {
            type: "string",
            description: "A phone number if one appears anywhere in the email. Omit if none.",
          },
          language: {
            type: "string",
            enum: SUPPORTED_LANGUAGES,
            description: "The language the email is written in. Default to \"en\" if genuinely unclear (e.g. the email is just a phone number).",
          },
        },
        required: ["family_name", "grade_requested", "language"],
      },
    },
  });

  if (!result) return null;

  const matchedGradeLevel = result.grade_requested === UNSPECIFIED ? null : result.grade_requested;

  return {
    familyName: result.family_name.trim() || guessNameFromEmail(input),
    studentName: result.student_name?.trim() || null,
    matchedGradeLevel,
    gradeRequestedRaw: matchedGradeLevel ?? result.grade_requested_raw_text?.trim() ?? UNSPECIFIED,
    phone: result.phone_number ? normalizePhoneToE164(result.phone_number) : null,
    language: isPreferredLanguage(result.language) ? result.language : "en",
  };
}

function extractHeuristically(input: ExtractInput): ExtractedInquiryFields {
  const haystack = `${input.subject}\n${input.bodyText}`;

  const phoneMatch = haystack.match(/\+?[\d][\d\s().-]{6,}\d/);
  const phone = phoneMatch ? normalizePhoneToE164(phoneMatch[0]) : null;
  const matchedGradeLevel = matchGradeLevel(haystack, input.schoolGradeLevels);

  return {
    familyName: guessNameFromEmail(input),
    studentName: null,
    matchedGradeLevel,
    gradeRequestedRaw: matchedGradeLevel ?? UNSPECIFIED,
    phone,
    language: detectLanguageHeuristically(haystack),
  };
}

function guessNameFromEmail(input: ExtractInput): string {
  if (input.fromName?.trim()) return input.fromName.trim();
  const localPart = input.fromEmail.split("@")[0] ?? "";
  return localPart
    .replace(/[._+]/g, " ")
    .split(" ")
    .filter(Boolean)
    .map((part) => part[0]?.toUpperCase() + part.slice(1))
    .join(" ") || "Prospective family";
}
