import "server-only";

import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import type { Database } from "@/lib/supabase/database.types";
import type { PostmarkInboundPayload } from "@/lib/email/postmark";
import { sendEmail } from "@/lib/email/postmark";
import { extractInquiryFields } from "@/lib/intake/extract-inquiry-fields";
import { checkAvailability } from "@/lib/availability";
import { composeSameDayReply } from "@/lib/messaging/compose-reply";
import { logAudit } from "@/lib/audit";
import { syncInquiryToAirtable } from "@/lib/airtable/sync";

type SupabaseAdmin = ReturnType<typeof createAdminSupabaseClient>;

export type InboundEmailResult =
  | { outcome: "duplicate" }
  | { outcome: "unrouted"; recipient: string }
  | { outcome: "appended_to_existing"; inquiryId: string }
  | { outcome: "new_inquiry_replied"; inquiryId: string };

const OPEN_STATUSES_EXCLUDED = "(enrolled,lost)";

export async function handleInboundEmail(payload: PostmarkInboundPayload): Promise<InboundEmailResult> {
  const db = createAdminSupabaseClient();

  const existingMessage = await db
    .from("messages")
    .select("id")
    .eq("provider_message_id", payload.MessageID)
    .maybeSingle();
  if (existingMessage.data) {
    return { outcome: "duplicate" };
  }

  const recipient = (payload.OriginalRecipient || payload.To || "").trim().toLowerCase();
  const { data: school } = await db
    .from("schools")
    .select("*")
    .eq("inbound_email", recipient)
    .eq("status", "active")
    .maybeSingle();

  if (!school) {
    console.error("Inbound email addressed to unrecognized/inactive school inbox", recipient);
    return { outcome: "unrouted", recipient };
  }

  const fromEmail = (payload.FromFull?.Email || payload.From).trim().toLowerCase();
  const bodyText = payload.StrippedTextReply || payload.TextBody || "";

  const extracted = await extractInquiryFields({
    fromName: payload.FromFull?.Name || payload.FromName || null,
    fromEmail,
    subject: payload.Subject || "(no subject)",
    bodyText,
    schoolGradeLevels: school.grade_levels,
  });

  const { inquiry, isNew } = await findOrCreateInquiry(db, {
    schoolId: school.id,
    familyEmail: fromEmail,
    familyName: extracted.familyName,
    studentName: extracted.studentName,
    phone: extracted.phone,
    gradeRequested: extracted.gradeRequestedRaw,
    language: extracted.language,
  });

  await db.from("messages").insert({
    school_id: school.id,
    inquiry_id: inquiry.id,
    direction: "inbound",
    channel: "email",
    from_address: fromEmail,
    to_address: recipient,
    subject: payload.Subject,
    body: bodyText,
    provider_message_id: payload.MessageID,
    sent_at: payload.Date ? new Date(payload.Date).toISOString() : new Date().toISOString(),
  });

  await logAudit(db, {
    schoolId: school.id,
    inquiryId: inquiry.id,
    actorType: "system",
    action: "inbound_email_received",
    detail: { messageId: payload.MessageID, isNewInquiry: isNew },
  });

  await syncInquiryToAirtable(db, inquiry.id).catch((err) =>
    console.error("Airtable sync failed (non-fatal)", err),
  );

  if (!isNew) {
    return { outcome: "appended_to_existing", inquiryId: inquiry.id };
  }

  await replyToNewInquiry(db, school, inquiry, extracted.matchedGradeLevel);
  return { outcome: "new_inquiry_replied", inquiryId: inquiry.id };
}

async function findOrCreateInquiry(
  db: SupabaseAdmin,
  fields: {
    schoolId: string;
    familyEmail: string;
    familyName: string;
    studentName: string | null;
    phone: string | null;
    gradeRequested: string;
    language: Database["public"]["Tables"]["inquiries"]["Row"]["preferred_language"];
  },
): Promise<{ inquiry: Database["public"]["Tables"]["inquiries"]["Row"]; isNew: boolean }> {
  const { data: created, error: insertError } = await db
    .from("inquiries")
    .insert({
      school_id: fields.schoolId,
      source: "email",
      family_name: fields.familyName,
      family_email: fields.familyEmail,
      family_phone: fields.phone,
      student_name: fields.studentName,
      grade_requested: fields.gradeRequested,
      preferred_language: fields.language,
      status: "new",
    })
    .select("*")
    .single();

  if (!insertError && created) {
    return { inquiry: created, isNew: true };
  }

  // Unique violation on the open-inquiry dedup index: this family already
  // has an open inquiry for this grade — append to it instead of spamming a
  // second row (and a second, redundant same-day reply).
  if (insertError?.code === "23505") {
    const { data: existing, error: selectError } = await db
      .from("inquiries")
      .select("*")
      .eq("school_id", fields.schoolId)
      .eq("grade_requested", fields.gradeRequested)
      .ilike("family_email", fields.familyEmail)
      .not("status", "in", OPEN_STATUSES_EXCLUDED)
      .limit(1)
      .maybeSingle();

    if (!selectError && existing) {
      return { inquiry: existing, isNew: false };
    }
  }

  throw new Error(`Failed to find-or-create inquiry: ${insertError?.message ?? "unknown error"}`);
}

async function replyToNewInquiry(
  db: SupabaseAdmin,
  school: Database["public"]["Tables"]["schools"]["Row"],
  inquiry: Database["public"]["Tables"]["inquiries"]["Row"],
  matchedGradeLevel: string | null,
): Promise<void> {
  const availability = matchedGradeLevel ? await checkAvailability(db, school.id, matchedGradeLevel) : null;

  const reply = await composeSameDayReply({
    schoolName: school.name,
    familyName: inquiry.family_name,
    studentName: inquiry.student_name,
    gradeRequested: matchedGradeLevel ?? inquiry.grade_requested,
    availability,
    inquiryId: inquiry.id,
    language: inquiry.preferred_language,
  });

  if (!inquiry.family_email) {
    console.error("Cannot send reply: inquiry has no family_email", inquiry.id);
    return;
  }

  try {
    const sent = await sendEmail({
      to: inquiry.family_email,
      subject: reply.subject,
      textBody: reply.textBody,
      replyTo: school.inbound_email,
    });

    await db.from("messages").insert({
      school_id: school.id,
      inquiry_id: inquiry.id,
      direction: "outbound",
      channel: "email",
      from_address: school.inbound_email,
      to_address: inquiry.family_email,
      subject: reply.subject,
      body: reply.textBody,
      provider_message_id: sent.messageId,
    });

    const newStatus = availability?.hasSpace ? "qualified" : "new";
    if (newStatus !== inquiry.status) {
      await db.from("inquiries").update({ status: newStatus }).eq("id", inquiry.id);
    }

    await logAudit(db, {
      schoolId: school.id,
      inquiryId: inquiry.id,
      actorType: "agent",
      action: "same_day_reply_sent",
      detail: {
        hasSpace: availability?.hasSpace ?? null,
        seatsAvailable: availability?.seatsAvailable ?? null,
        gradeMatched: matchedGradeLevel,
      },
    });
  } catch (err) {
    console.error("Failed to send same-day reply", inquiry.id, err);
    await logAudit(db, {
      schoolId: school.id,
      inquiryId: inquiry.id,
      actorType: "agent",
      action: "same_day_reply_failed",
      detail: { error: err instanceof Error ? err.message : String(err) },
    });
  }
}
