import { z } from "zod";

/**
 * Every secret the app needs lives in environment config — never hardcoded —
 * and is validated once here at startup so a missing/malformed value fails
 * loudly at boot instead of surfacing as a confusing runtime error deep in a
 * webhook handler.
 */

const serverSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),

  // AES-256-GCM key for encrypting per-school OAuth refresh tokens at rest,
  // base64-encoded, must decode to exactly 32 bytes.
  ENCRYPTION_KEY: z
    .string()
    .min(1)
    .refine((v) => Buffer.from(v, "base64").length === 32, {
      message: "ENCRYPTION_KEY must be a base64-encoded 32-byte key (openssl rand -base64 32)",
    }),

  POSTMARK_SERVER_TOKEN: z.string().min(1),
  POSTMARK_INBOUND_USERNAME: z.string().min(1),
  POSTMARK_INBOUND_PASSWORD: z.string().min(1),
  POSTMARK_FROM_EMAIL: z.string().email(),

  GOOGLE_OAUTH_CLIENT_ID: z.string().min(1),
  GOOGLE_OAUTH_CLIENT_SECRET: z.string().min(1),

  AIRTABLE_API_KEY: z.string().min(1).optional(),

  // Optional: powers free-text field extraction from inbound emails and
  // grounded reply drafting. Both features have a deterministic fallback
  // (see src/lib/intake/extract-inquiry-fields.ts and
  // src/lib/messaging/compose-reply.ts) so the pipeline keeps working
  // end-to-end without this key — it upgrades quality, it isn't load-bearing.
  ANTHROPIC_API_KEY: z.string().min(1).optional(),

  APP_BASE_URL: z.string().url(),
});

export type ServerEnv = z.infer<typeof serverSchema>;

let cached: ServerEnv | null = null;

/** Validates and returns server-only env vars. Call only from server code. */
export function getServerEnv(): ServerEnv {
  if (cached) return cached;
  const parsed = serverSchema.safeParse(process.env);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `  - ${i.path.join(".")}: ${i.message}`)
      .join("\n");
    throw new Error(
      `Invalid/missing environment configuration:\n${issues}\n\nSee .env.example.`,
    );
  }
  cached = parsed.data;
  return cached;
}

const publicSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
});

/** Safe to import from client components. */
export function getPublicEnv() {
  return publicSchema.parse({
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  });
}
