import "server-only";

import { createClient } from "@supabase/supabase-js";
import { getServerEnv } from "@/lib/env";
import type { Database } from "./database.types";

/**
 * Service-role Supabase client. This BYPASSES Row-Level Security entirely —
 * it is the one deliberate cross-school-capable path described in the data
 * model spec, and it must only ever be used by trusted server code that
 * itself enforces the right school_id (inbound email webhook, calendar
 * sync, Airtable sync, cron). Never import this into a Client Component or
 * anything that runs on behalf of an arbitrary staff session — use
 * createServerSupabaseClient for that instead.
 */
export function createAdminSupabaseClient() {
  const env = getServerEnv();
  return createClient<Database>(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
