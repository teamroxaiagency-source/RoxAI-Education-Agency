"use client";

import { createBrowserClient } from "@supabase/ssr";
import { getPublicEnv } from "@/lib/env";
import type { Database } from "./database.types";

/**
 * Client-side Supabase client, bound to the anon key. Every query made
 * through this client runs as `authenticated` under RLS — it can never see
 * another school's rows, by construction, not by convention.
 */
export function createBrowserSupabaseClient() {
  const env = getPublicEnv();
  return createBrowserClient<Database>(env.NEXT_PUBLIC_SUPABASE_URL, env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
}
