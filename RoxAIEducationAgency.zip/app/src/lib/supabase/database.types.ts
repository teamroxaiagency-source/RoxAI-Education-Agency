/**
 * Hand-authored to match supabase/migrations/*.sql exactly. Once the pilot
 * school's project exists, prefer regenerating this from the live schema:
 *   supabase gen types typescript --project-id <ref> > src/lib/supabase/database.types.ts
 *
 * Relationships arrays are required (even empty) for @supabase/supabase-js
 * to structurally match its GenericTable/GenericSchema constraints — without
 * them (and without Views/Functions on the schema) every Row/Insert/Update
 * type silently collapses to `never`.
 */

export type InquirySource = "email" | "whatsapp" | "web_form";
export type InquiryStatus = "new" | "qualified" | "scheduled" | "enrolled" | "lost";
export type StaffRole = "admissions_staff" | "school_admin";
export type MessageDirection = "inbound" | "outbound";
export type MessageChannel = "email" | "whatsapp" | "web_form" | "system";
export type PreferredLanguage = "en" | "sw" | "fr";
export type AuditActorType = "agent" | "staff" | "system";

export interface Database {
  public: {
    Tables: {
      schools: {
        Row: {
          id: string;
          name: string;
          slug: string;
          status: "trial" | "active" | "paused" | "offboarded";
          timezone: string;
          inbound_email: string;
          grade_levels: string[];
          contact_channels: { email: boolean; whatsapp: boolean; web_form: boolean };
          term_start_date: string | null;
          term_end_date: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["schools"]["Row"]> & {
          name: string;
          slug: string;
          inbound_email: string;
        };
        Update: Partial<Database["public"]["Tables"]["schools"]["Row"]>;
        Relationships: [];
      };
      staff_users: {
        Row: {
          id: string;
          school_id: string;
          email: string;
          full_name: string;
          role: StaffRole;
          active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["staff_users"]["Row"]> & {
          id: string;
          school_id: string;
          email: string;
          full_name: string;
        };
        Update: Partial<Database["public"]["Tables"]["staff_users"]["Row"]>;
        Relationships: [
          {
            foreignKeyName: "staff_users_school_id_fkey";
            columns: ["school_id"];
            isOneToOne: false;
            referencedRelation: "schools";
            referencedColumns: ["id"];
          },
        ];
      };
      availability: {
        Row: {
          id: string;
          school_id: string;
          grade_level: string;
          capacity_total: number;
          seats_taken: number;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["availability"]["Row"]> & {
          school_id: string;
          grade_level: string;
          capacity_total: number;
        };
        Update: Partial<Database["public"]["Tables"]["availability"]["Row"]>;
        Relationships: [
          {
            foreignKeyName: "availability_school_id_fkey";
            columns: ["school_id"];
            isOneToOne: false;
            referencedRelation: "schools";
            referencedColumns: ["id"];
          },
        ];
      };
      inquiries: {
        Row: {
          id: string;
          school_id: string;
          source: InquirySource;
          family_name: string;
          family_email: string | null;
          family_phone: string | null;
          student_name: string | null;
          grade_requested: string;
          status: InquiryStatus;
          preferred_language: PreferredLanguage;
          assigned_staff_id: string | null;
          notes: string | null;
          first_contact_at: string;
          last_activity_at: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["inquiries"]["Row"]> & {
          school_id: string;
          source: InquirySource;
          family_name: string;
          grade_requested: string;
        };
        Update: Partial<Database["public"]["Tables"]["inquiries"]["Row"]>;
        Relationships: [
          {
            foreignKeyName: "inquiries_school_id_fkey";
            columns: ["school_id"];
            isOneToOne: false;
            referencedRelation: "schools";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "inquiries_assigned_staff_id_fkey";
            columns: ["assigned_staff_id"];
            isOneToOne: false;
            referencedRelation: "staff_users";
            referencedColumns: ["id"];
          },
        ];
      };
      messages: {
        Row: {
          id: string;
          school_id: string;
          inquiry_id: string;
          direction: MessageDirection;
          channel: MessageChannel;
          from_address: string | null;
          to_address: string | null;
          subject: string | null;
          body: string;
          provider_message_id: string | null;
          sent_at: string;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["messages"]["Row"]> & {
          school_id: string;
          inquiry_id: string;
          direction: MessageDirection;
          channel: MessageChannel;
          body: string;
        };
        Update: Partial<Database["public"]["Tables"]["messages"]["Row"]>;
        Relationships: [
          {
            foreignKeyName: "messages_school_id_fkey";
            columns: ["school_id"];
            isOneToOne: false;
            referencedRelation: "schools";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "messages_inquiry_id_fkey";
            columns: ["inquiry_id"];
            isOneToOne: false;
            referencedRelation: "inquiries";
            referencedColumns: ["id"];
          },
        ];
      };
      audit_log: {
        Row: {
          id: string;
          school_id: string;
          inquiry_id: string | null;
          actor_type: AuditActorType;
          actor_id: string | null;
          action: string;
          detail: Record<string, unknown>;
          created_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["audit_log"]["Row"]> & {
          school_id: string;
          actor_type: AuditActorType;
          action: string;
        };
        Update: Partial<Database["public"]["Tables"]["audit_log"]["Row"]>;
        Relationships: [
          {
            foreignKeyName: "audit_log_school_id_fkey";
            columns: ["school_id"];
            isOneToOne: false;
            referencedRelation: "schools";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "audit_log_inquiry_id_fkey";
            columns: ["inquiry_id"];
            isOneToOne: false;
            referencedRelation: "inquiries";
            referencedColumns: ["id"];
          },
        ];
      };
      school_integrations: {
        Row: {
          school_id: string;
          google_calendar_id: string | null;
          google_refresh_token_ciphertext: string | null;
          google_connected_by: string | null;
          google_connected_at: string | null;
          airtable_base_id: string | null;
          airtable_table_name: string | null;
          updated_at: string;
        };
        Insert: Partial<Database["public"]["Tables"]["school_integrations"]["Row"]> & {
          school_id: string;
        };
        Update: Partial<Database["public"]["Tables"]["school_integrations"]["Row"]>;
        Relationships: [
          {
            foreignKeyName: "school_integrations_school_id_fkey";
            columns: ["school_id"];
            isOneToOne: true;
            referencedRelation: "schools";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: Record<string, never>;
    Functions: {
      current_staff_school_id: {
        Args: Record<string, never>;
        Returns: string;
      };
      current_staff_role: {
        Args: Record<string, never>;
        Returns: string;
      };
      onboard_school: {
        Args: {
          p_name: string;
          p_slug: string;
          p_timezone: string;
          p_inbound_email: string;
          p_grade_levels: { grade_level: string; capacity_total: number }[];
          p_term_start: string | null;
          p_term_end: string | null;
        };
        Returns: string;
      };
    };
  };
}
