import "server-only";

import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { getPublicEnv } from "@/lib/env";
import type { Database } from "./database.types";

/**
 * Server-side Supabase client for use in Server Components, Route Handlers,
 * and Server Actions. Bound to the anon key + the caller's session cookie,
 * so it runs under RLS as `authenticated` — same tenant guarantees as the
 * browser client, just usable on the server.
 */
export async function createServerSupabaseClient() {
  const env = getPublicEnv();
  const cookieStore = await cookies();

  return createServerClient<Database>(env.NEXT_PUBLIC_SUPABASE_URL, env.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet) {
        try {
          for (const { name, value, options } of cookiesToSet) {
            cookieStore.set(name, value, options);
          }
        } catch {
          // Called from a Server Component render, where cookies are
          // read-only. Safe to ignore because the proxy (middleware)
          // refreshes the session cookie on every request instead.
        }
      },
    },
  });
}
