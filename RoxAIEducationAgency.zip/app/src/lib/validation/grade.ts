const ORDINAL_WORDS: Record<string, string> = {
  first: "1",
  second: "2",
  third: "3",
  fourth: "4",
  fifth: "5",
  sixth: "6",
  seventh: "7",
  eighth: "8",
  ninth: "9",
  tenth: "10",
  eleventh: "11",
  twelfth: "12",
};

function normalize(text: string): string {
  let t = text.toLowerCase().trim();
  for (const [word, digit] of Object.entries(ORDINAL_WORDS)) {
    t = t.replace(new RegExp(`\\b${word}\\b`, "g"), digit);
  }
  t = t.replace(/(\d+)(st|nd|rd|th)\b/g, "$1");
  t = t.replace(/\bkindergarten\b/g, "k");
  t = t.replace(/\bpre[- ]?k(indergarten)?\b/g, "prek");
  t = t.replace(/\bgrade\b/g, "").replace(/\s+/g, " ").trim();
  return t;
}

/**
 * Matches free text against a school's actual configured grade levels
 * (e.g. ["Pre-K", "Kindergarten", "Grade 1", ... "Grade 8"]) so the agent
 * only ever checks/promises availability for a grade the school actually
 * offers — never a hallucinated or misheard one. Returns the school's exact
 * label, or null if nothing matches confidently.
 */
export function matchGradeLevel(freeText: string, schoolGradeLevels: string[]): string | null {
  const needle = normalize(freeText);
  if (!needle) return null;

  for (const label of schoolGradeLevels) {
    if (normalize(label) === needle) return label;
  }
  // Loose containment match as a second pass (e.g. "my son is starting 1st
  // grade this fall" contains "1").
  for (const label of schoolGradeLevels) {
    const labelNorm = normalize(label);
    if (labelNorm && new RegExp(`\\b${labelNorm}\\b`).test(needle)) return label;
  }
  return null;
}
