import { parsePhoneNumberFromString } from "libphonenumber-js";

/**
 * Normalizes a raw phone number to E.164 (matches the DB CHECK constraint
 * on inquiries.family_phone). Returns null for anything that doesn't parse
 * as a real number rather than throwing — a malformed phone number should
 * never corrupt intake, just get dropped in favor of email-only contact.
 */
export function normalizePhoneToE164(raw: string, defaultRegion: string = "US"): string | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  const parsed = parsePhoneNumberFromString(trimmed, defaultRegion as never);
  if (!parsed || !parsed.isValid()) return null;
  return parsed.number; // E.164, e.g. +14155552671
}
