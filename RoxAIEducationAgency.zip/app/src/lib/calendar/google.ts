import "server-only";

import type { SupabaseClient } from "@supabase/supabase-js";
import { getServerEnv } from "@/lib/env";
import { decryptSecret, encryptSecret } from "@/lib/crypto";
import type { Database } from "@/lib/supabase/database.types";

// Talks to Google's OAuth2 and Calendar REST APIs directly via fetch rather
// than the `googleapis` SDK — that package pulls in Node HTTP internals
// (gaxios, node-gtoken) that don't run reliably on Cloudflare Workers. Plain
// fetch is also what Workers (and every other edge runtime) natively
// support, so this has no runtime-specific branches.

const CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const CALENDAR_API = "https://www.googleapis.com/calendar/v3";

export function getGoogleRedirectUri(): string {
  return `${getServerEnv().APP_BASE_URL}/api/integrations/google/callback`;
}

/** `state` embeds the school + staff that initiated the connect flow (see integrations/google/connect route for signing). */
export function buildGoogleAuthUrl(state: string): string {
  const env = getServerEnv();
  const params = new URLSearchParams({
    client_id: env.GOOGLE_OAUTH_CLIENT_ID,
    redirect_uri: getGoogleRedirectUri(),
    response_type: "code",
    access_type: "offline",
    prompt: "consent", // forces a refresh_token even on a re-connect
    scope: CALENDAR_SCOPE,
    state,
  });
  return `${AUTH_URL}?${params.toString()}`;
}

export async function exchangeCodeForRefreshToken(code: string): Promise<string> {
  const env = getServerEnv();
  const response = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: env.GOOGLE_OAUTH_CLIENT_ID,
      client_secret: env.GOOGLE_OAUTH_CLIENT_SECRET,
      redirect_uri: getGoogleRedirectUri(),
      grant_type: "authorization_code",
    }),
  });

  if (!response.ok) {
    throw new Error(`Google token exchange failed (${response.status}): ${await response.text()}`);
  }

  const data = (await response.json()) as { refresh_token?: string };
  if (!data.refresh_token) {
    throw new Error(
      "Google did not return a refresh_token. This usually means the school's Google account already granted access — disconnect it in Google Account permissions and retry.",
    );
  }
  return data.refresh_token;
}

async function getAccessTokenForSchool(
  db: SupabaseClient<Database>,
  schoolId: string,
): Promise<{ accessToken: string; calendarId: string } | null> {
  const { data: integration, error } = await db
    .from("school_integrations")
    .select("google_calendar_id, google_refresh_token_ciphertext")
    .eq("school_id", schoolId)
    .maybeSingle();

  if (error || !integration?.google_refresh_token_ciphertext) {
    return null;
  }

  const refreshToken = decryptSecret(integration.google_refresh_token_ciphertext);
  const env = getServerEnv();

  const response = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      refresh_token: refreshToken,
      client_id: env.GOOGLE_OAUTH_CLIENT_ID,
      client_secret: env.GOOGLE_OAUTH_CLIENT_SECRET,
      grant_type: "refresh_token",
    }),
  });

  if (!response.ok) {
    console.error("Google access token refresh failed", schoolId, response.status, await response.text());
    return null;
  }

  const data = (await response.json()) as { access_token: string };
  return { accessToken: data.access_token, calendarId: integration.google_calendar_id || "primary" };
}

interface FreeBusyPeriod {
  start: string;
  end: string;
}

async function queryFreeBusy(
  accessToken: string,
  calendarId: string,
  timeMin: string,
  timeMax: string,
): Promise<FreeBusyPeriod[]> {
  const response = await fetch(`${CALENDAR_API}/freeBusy`, {
    method: "POST",
    headers: {
      authorization: `Bearer ${accessToken}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({ timeMin, timeMax, items: [{ id: calendarId }] }),
  });

  if (!response.ok) {
    throw new Error(`Google freebusy query failed (${response.status}): ${await response.text()}`);
  }

  const data = (await response.json()) as { calendars?: Record<string, { busy?: FreeBusyPeriod[] }> };
  return data.calendars?.[calendarId]?.busy ?? [];
}

export interface OpenSlot {
  start: string; // ISO 8601
  end: string; // ISO 8601
}

/**
 * Generates candidate tour/call slots within school working hours over the
 * next `daysAhead` days, then removes anything that overlaps a real event
 * on the school's connected calendar (via freebusy query) — so every slot
 * offered to a family is genuinely open right now, not just plausible.
 */
export async function listOpenSlots(
  db: SupabaseClient<Database>,
  schoolId: string,
  options: {
    daysAhead?: number;
    slotMinutes?: number;
    workingHourStart?: number; // 24h, school local time
    workingHourEnd?: number;
    timezone: string;
  },
): Promise<OpenSlot[]> {
  const conn = await getAccessTokenForSchool(db, schoolId);
  if (!conn) return [];

  const daysAhead = options.daysAhead ?? 7;
  const slotMinutes = options.slotMinutes ?? 30;
  const workingHourStart = options.workingHourStart ?? 9;
  const workingHourEnd = options.workingHourEnd ?? 16;

  const now = new Date();
  const timeMin = new Date(now.getTime() + 24 * 60 * 60 * 1000); // same-day cutoff: earliest tomorrow
  const timeMax = new Date(now.getTime() + (daysAhead + 1) * 24 * 60 * 60 * 1000);

  const busyPeriods = await queryFreeBusy(conn.accessToken, conn.calendarId, timeMin.toISOString(), timeMax.toISOString());
  const busy = busyPeriods.map((b) => ({ start: new Date(b.start).getTime(), end: new Date(b.end).getTime() }));

  const slots: OpenSlot[] = [];
  for (let dayOffset = 1; dayOffset <= daysAhead; dayOffset++) {
    const day = new Date(now);
    day.setDate(day.getDate() + dayOffset);
    const dayOfWeek = day.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) continue; // weekdays only

    for (let hour = workingHourStart; hour < workingHourEnd; hour += slotMinutes / 60) {
      const slotStart = new Date(day);
      slotStart.setHours(Math.floor(hour), Math.round((hour % 1) * 60), 0, 0);
      const slotEnd = new Date(slotStart.getTime() + slotMinutes * 60 * 1000);

      const overlapsBusy = busy.some((b) => slotStart.getTime() < b.end && slotEnd.getTime() > b.start);
      if (!overlapsBusy) {
        slots.push({ start: slotStart.toISOString(), end: slotEnd.toISOString() });
      }
    }
  }

  return slots;
}

/** Re-checks the specific slot is still free, then books it. Throws if it's been taken since it was offered. */
export async function bookSlot(
  db: SupabaseClient<Database>,
  schoolId: string,
  slot: { start: string; end: string; summary: string; description: string; attendeeEmail: string },
): Promise<{ eventId: string; htmlLink: string | null }> {
  const conn = await getAccessTokenForSchool(db, schoolId);
  if (!conn) throw new Error("School has no connected Google Calendar");

  const busy = await queryFreeBusy(conn.accessToken, conn.calendarId, slot.start, slot.end);
  if (busy.length > 0) {
    throw new Error("This slot was just booked by someone else — please pick another time.");
  }

  const response = await fetch(
    `${CALENDAR_API}/calendars/${encodeURIComponent(conn.calendarId)}/events?sendUpdates=all`,
    {
      method: "POST",
      headers: {
        authorization: `Bearer ${conn.accessToken}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        summary: slot.summary,
        description: slot.description,
        start: { dateTime: slot.start },
        end: { dateTime: slot.end },
        attendees: [{ email: slot.attendeeEmail }],
      }),
    },
  );

  if (!response.ok) {
    throw new Error(`Google calendar event creation failed (${response.status}): ${await response.text()}`);
  }

  const event = (await response.json()) as { id: string; htmlLink?: string };
  return { eventId: event.id, htmlLink: event.htmlLink ?? null };
}

export async function storeGoogleConnection(
  db: SupabaseClient<Database>,
  params: { schoolId: string; refreshToken: string; connectedByStaffId: string; calendarId?: string },
): Promise<void> {
  const { error } = await db.from("school_integrations").upsert({
    school_id: params.schoolId,
    google_refresh_token_ciphertext: encryptSecret(params.refreshToken),
    google_calendar_id: params.calendarId ?? "primary",
    google_connected_by: params.connectedByStaffId,
    google_connected_at: new Date().toISOString(),
  });
  if (error) throw new Error(`Failed to store Google Calendar connection: ${error.message}`);
}
