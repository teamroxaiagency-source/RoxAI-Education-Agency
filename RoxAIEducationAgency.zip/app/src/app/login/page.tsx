import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { LoginForm } from "./login-form";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const { next } = await searchParams;

  // No proxy/middleware in front of this route (see "Deploying to Cloudflare
  // Workers" in app/README.md for why) — an already-signed-in visitor is
  // bounced onward here instead, same outcome.
  const supabase = await createServerSupabaseClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (user) {
    redirect(next && next.startsWith("/") ? next : "/pipeline");
  }

  return (
    <div className="flex flex-1 items-center justify-center bg-neutral-50 px-4">
      <div className="w-full max-w-sm rounded-lg border border-neutral-200 bg-white p-6 shadow-sm">
        <h1 className="mb-1 text-lg font-semibold text-neutral-900">RoxAI Admissions</h1>
        <p className="mb-6 text-sm text-neutral-500">Sign in to your school&rsquo;s inquiry pipeline.</p>
        <LoginForm next={next} />
      </div>
    </div>
  );
}
