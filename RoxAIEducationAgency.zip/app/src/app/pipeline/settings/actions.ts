"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireCurrentStaff } from "@/lib/auth/current-staff";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { logAudit } from "@/lib/audit";

const availabilitySchema = z.object({
  availabilityId: z.string().uuid(),
  capacityTotal: z.coerce.number().int().min(0),
  seatsTaken: z.coerce.number().int().min(0),
});

export async function updateAvailability(formData: FormData): Promise<{ error?: string }> {
  const parsed = availabilitySchema.safeParse({
    availabilityId: formData.get("availabilityId"),
    capacityTotal: formData.get("capacityTotal"),
    seatsTaken: formData.get("seatsTaken"),
  });
  if (!parsed.success) return { error: "Invalid capacity/seats value" };
  if (parsed.data.seatsTaken > parsed.data.capacityTotal) {
    return { error: "Seats taken can't exceed capacity" };
  }

  // RLS itself enforces school_admin-only + own-school-only (see
  // availability_update_own_school_admin policy) — no manual role check
  // needed here, the database refuses the write outright otherwise.
  const supabase = await createServerSupabaseClient();
  const { error } = await supabase
    .from("availability")
    .update({ capacity_total: parsed.data.capacityTotal, seats_taken: parsed.data.seatsTaken })
    .eq("id", parsed.data.availabilityId);

  if (error) return { error: error.message };

  revalidatePath("/pipeline/settings");
  return {};
}

const airtableSchema = z.object({
  baseId: z.string().trim().min(1).max(200),
  tableName: z.string().trim().min(1).max(200),
});

export async function saveAirtableConfig(formData: FormData): Promise<{ error?: string }> {
  const staff = await requireCurrentStaff();
  if (staff.role !== "school_admin") return { error: "Only a school admin can change this." };

  const parsed = airtableSchema.safeParse({
    baseId: formData.get("baseId"),
    tableName: formData.get("tableName"),
  });
  if (!parsed.success) return { error: "Enter a valid Airtable base ID and table name." };

  // school_integrations has zero client-facing RLS policies by design, so
  // this write goes through the service role — gated by the role check
  // above rather than a database policy.
  const admin = createAdminSupabaseClient();
  const { error } = await admin.from("school_integrations").upsert({
    school_id: staff.school_id,
    airtable_base_id: parsed.data.baseId,
    airtable_table_name: parsed.data.tableName,
  });
  if (error) return { error: error.message };

  await logAudit(admin, {
    schoolId: staff.school_id,
    actorType: "staff",
    actorId: staff.id,
    action: "airtable_config_updated",
  });

  revalidatePath("/pipeline/settings");
  return {};
}
