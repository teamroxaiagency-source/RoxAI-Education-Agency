"use client";

import { useActionState } from "react";
import { saveAirtableConfig } from "./actions";

type State = { error?: string } | null;

export function AirtableForm({ baseId, tableName }: { baseId: string; tableName: string }) {
  const [state, formAction, pending] = useActionState<State, FormData>(async (_prev, formData) => {
    const res = await saveAirtableConfig(formData);
    return res.error ? res : null;
  }, null);

  return (
    <form action={formAction} className="flex flex-col gap-3">
      <div className="flex flex-col gap-1">
        <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Airtable Base ID</label>
        <input
          name="baseId"
          defaultValue={baseId}
          placeholder="appXXXXXXXXXXXXXX"
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Table name</label>
        <input
          name="tableName"
          defaultValue={tableName}
          placeholder="Leads"
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        />
      </div>
      {state?.error ? <p className="text-sm text-red-600">{state.error}</p> : null}
      <button
        type="submit"
        disabled={pending}
        className="self-start rounded-md bg-neutral-900 px-3 py-1.5 text-sm font-medium text-white disabled:opacity-50"
      >
        {pending ? "Saving…" : "Save"}
      </button>
    </form>
  );
}
