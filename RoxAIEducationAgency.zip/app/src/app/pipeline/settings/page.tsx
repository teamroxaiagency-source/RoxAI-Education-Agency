import { redirect } from "next/navigation";
import { requireCurrentStaff } from "@/lib/auth/current-staff";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { AvailabilityRow } from "./availability-row";
import { AirtableForm } from "./airtable-form";

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ google_connected?: string; google_error?: string }>;
}) {
  const staff = await requireCurrentStaff();
  if (staff.role !== "school_admin") redirect("/pipeline");

  const { google_connected, google_error } = await searchParams;
  const supabase = await createServerSupabaseClient();

  const [{ data: availability }, { data: integration }] = await Promise.all([
    supabase.from("availability").select("*").eq("school_id", staff.school_id).order("grade_level"),
    supabase.from("school_integrations").select("*").eq("school_id", staff.school_id).maybeSingle(),
  ]);

  return (
    <div className="flex flex-col gap-6 p-6">
      {google_connected ? (
        <p className="rounded-md bg-green-50 p-3 text-sm text-green-800">Google Calendar connected.</p>
      ) : null}
      {google_error ? (
        <p className="rounded-md bg-red-50 p-3 text-sm text-red-800">Couldn&rsquo;t connect Google Calendar ({google_error}).</p>
      ) : null}

      <section className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="mb-1 text-sm font-semibold text-neutral-900">Google Calendar</h2>
        <p className="mb-3 text-sm text-neutral-500">
          {integration?.google_calendar_id
            ? `Connected (calendar: ${integration.google_calendar_id}).`
            : "Not connected — the tour/call booking page can't offer real slots until this is connected."}
        </p>
        <a
          href="/api/integrations/google/connect"
          className="inline-block rounded-md bg-neutral-900 px-3 py-1.5 text-sm font-medium text-white"
        >
          {integration?.google_calendar_id ? "Reconnect" : "Connect Google Calendar"}
        </a>
      </section>

      <section className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="mb-1 text-sm font-semibold text-neutral-900">Airtable sync</h2>
        <p className="mb-3 text-sm text-neutral-500">
          Every inquiry is pushed to this Airtable base/table on create and status change.
        </p>
        <AirtableForm baseId={integration?.airtable_base_id ?? ""} tableName={integration?.airtable_table_name ?? ""} />
      </section>

      <section className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="mb-1 text-sm font-semibold text-neutral-900">Grade availability</h2>
        <p className="mb-3 text-sm text-neutral-500">
          Checked before every automated reply. Keep this current — it&rsquo;s what the agent tells families.
        </p>
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-200 text-left text-xs uppercase tracking-wide text-neutral-500">
              <th className="pb-2">Grade</th>
              <th className="pb-2">Capacity</th>
              <th className="pb-2">Seats taken</th>
              <th className="pb-2">Open</th>
            </tr>
          </thead>
          <tbody>
            {(availability ?? []).map((row) => (
              <AvailabilityRow
                key={row.id}
                id={row.id}
                gradeLevel={row.grade_level}
                capacityTotal={row.capacity_total}
                seatsTaken={row.seats_taken}
              />
            ))}
          </tbody>
        </table>
        {(availability ?? []).length === 0 ? (
          <p className="mt-2 text-sm text-neutral-400">
            No grade levels configured yet — contact RoxAI to set up initial capacity.
          </p>
        ) : null}
      </section>
    </div>
  );
}
