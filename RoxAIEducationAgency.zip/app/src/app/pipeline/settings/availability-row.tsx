"use client";

import { useState, useTransition } from "react";
import { updateAvailability } from "./actions";

export function AvailabilityRow({
  id,
  gradeLevel,
  capacityTotal,
  seatsTaken,
}: {
  id: string;
  gradeLevel: string;
  capacityTotal: number;
  seatsTaken: number;
}) {
  const [capacity, setCapacity] = useState(capacityTotal);
  const [taken, setTaken] = useState(seatsTaken);
  const [error, setError] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  function save(nextCapacity: number, nextTaken: number) {
    const formData = new FormData();
    formData.set("availabilityId", id);
    formData.set("capacityTotal", String(nextCapacity));
    formData.set("seatsTaken", String(nextTaken));
    startTransition(async () => {
      const res = await updateAvailability(formData);
      setError(res.error ?? null);
    });
  }

  return (
    <tr className="border-b border-neutral-100">
      <td className="py-2 pr-4 text-sm text-neutral-900">{gradeLevel}</td>
      <td className="py-2 pr-4">
        <input
          type="number"
          min={0}
          value={capacity}
          onChange={(e) => setCapacity(Number(e.target.value))}
          onBlur={() => save(capacity, taken)}
          className="w-20 rounded-md border border-neutral-300 px-2 py-1 text-sm"
        />
      </td>
      <td className="py-2 pr-4">
        <input
          type="number"
          min={0}
          value={taken}
          onChange={(e) => setTaken(Number(e.target.value))}
          onBlur={() => save(capacity, taken)}
          className="w-20 rounded-md border border-neutral-300 px-2 py-1 text-sm"
        />
      </td>
      <td className="py-2 text-sm text-neutral-500">{Math.max(capacity - taken, 0)} open</td>
      {error ? <td className="text-xs text-red-600">{error}</td> : null}
    </tr>
  );
}
