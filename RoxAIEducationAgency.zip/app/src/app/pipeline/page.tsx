import Link from "next/link";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import type { InquiryStatus } from "@/lib/supabase/database.types";
import { LANGUAGE_NAMES } from "@/lib/i18n/language";

const COLUMNS: { status: InquiryStatus; label: string }[] = [
  { status: "new", label: "New" },
  { status: "qualified", label: "Qualified" },
  { status: "scheduled", label: "Scheduled" },
  { status: "enrolled", label: "Enrolled" },
  { status: "lost", label: "Lost" },
];

export default async function PipelinePage() {
  const supabase = await createServerSupabaseClient();
  const { data: inquiries } = await supabase
    .from("inquiries")
    .select("id, family_name, student_name, grade_requested, status, last_activity_at, source, preferred_language")
    .order("last_activity_at", { ascending: false });

  const byStatus = new Map<InquiryStatus, typeof inquiries>();
  for (const col of COLUMNS) byStatus.set(col.status, []);
  for (const inquiry of inquiries ?? []) {
    byStatus.get(inquiry.status)?.push(inquiry);
  }

  return (
    <div className="flex h-full gap-4 overflow-x-auto p-6">
      {COLUMNS.map((col) => {
        const items = byStatus.get(col.status) ?? [];
        return (
          <div key={col.status} className="flex w-72 shrink-0 flex-col rounded-lg bg-neutral-100">
            <div className="flex items-center justify-between px-3 py-2">
              <h2 className="text-sm font-semibold text-neutral-700">{col.label}</h2>
              <span className="text-xs text-neutral-500">{items.length}</span>
            </div>
            <div className="flex flex-col gap-2 overflow-y-auto px-3 pb-3">
              {items.length === 0 ? <p className="px-1 text-xs text-neutral-400">No inquiries</p> : null}
              {items.map((inquiry) => (
                <Link
                  key={inquiry.id}
                  href={`/pipeline/${inquiry.id}`}
                  className="rounded-md border border-neutral-200 bg-white p-3 text-sm shadow-sm hover:border-neutral-400"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-medium text-neutral-900">{inquiry.family_name}</p>
                    {inquiry.preferred_language !== "en" ? (
                      <span className="shrink-0 rounded bg-neutral-100 px-1.5 py-0.5 text-[10px] font-medium uppercase text-neutral-500">
                        {LANGUAGE_NAMES[inquiry.preferred_language]}
                      </span>
                    ) : null}
                  </div>
                  {inquiry.student_name ? <p className="text-xs text-neutral-500">{inquiry.student_name}</p> : null}
                  <p className="mt-1 text-xs text-neutral-500">{inquiry.grade_requested}</p>
                  <p className="mt-2 text-[11px] uppercase tracking-wide text-neutral-400">
                    {inquiry.source} · {timeAgo(inquiry.last_activity_at)}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}
