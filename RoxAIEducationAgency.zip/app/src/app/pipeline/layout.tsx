import Link from "next/link";
import { requireCurrentStaff } from "@/lib/auth/current-staff";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { signOut } from "@/app/login/actions";

export default async function PipelineLayout({ children }: { children: React.ReactNode }) {
  const staff = await requireCurrentStaff();
  const supabase = await createServerSupabaseClient();
  const { data: school } = await supabase.from("schools").select("name").eq("id", staff.school_id).single();

  return (
    <div className="flex min-h-full flex-1 flex-col">
      <header className="flex items-center justify-between border-b border-neutral-200 bg-white px-6 py-3">
        <div className="flex items-center gap-6">
          <Link href="/pipeline" className="font-semibold text-neutral-900">
            {school?.name ?? "RoxAI Admissions"}
          </Link>
          <nav className="flex gap-4 text-sm text-neutral-600">
            <Link href="/pipeline" className="hover:text-neutral-900">
              Pipeline
            </Link>
            {staff.role === "school_admin" ? (
              <Link href="/pipeline/settings" className="hover:text-neutral-900">
                Settings
              </Link>
            ) : null}
          </nav>
        </div>
        <div className="flex items-center gap-3 text-sm text-neutral-600">
          <span>{staff.full_name}</span>
          <form action={signOut}>
            <button type="submit" className="text-neutral-500 hover:text-neutral-900">
              Sign out
            </button>
          </form>
        </div>
      </header>
      <main className="flex-1 bg-neutral-50">{children}</main>
    </div>
  );
}
