"use client";

import { useState, useTransition } from "react";
import { updateInquiryStatus, updateInquiryNotes, assignInquiry, updateInquiryLanguage } from "./actions";
import type { InquiryStatus, PreferredLanguage } from "@/lib/supabase/database.types";
import { LANGUAGE_NAMES, SUPPORTED_LANGUAGES } from "@/lib/i18n/language";

const STATUSES: InquiryStatus[] = ["new", "qualified", "scheduled", "enrolled", "lost"];

export function InquiryControls({
  inquiryId,
  initialStatus,
  initialNotes,
  initialAssignedStaffId,
  initialLanguage,
  staffOptions,
}: {
  inquiryId: string;
  initialStatus: InquiryStatus;
  initialNotes: string;
  initialAssignedStaffId: string | null;
  initialLanguage: PreferredLanguage;
  staffOptions: { id: string; full_name: string }[];
}) {
  const [status, setStatus] = useState(initialStatus);
  const [notes, setNotes] = useState(initialNotes);
  const [assignedStaffId, setAssignedStaffId] = useState(initialAssignedStaffId ?? "");
  const [language, setLanguage] = useState(initialLanguage);
  const [, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-4 rounded-lg border border-neutral-200 bg-white p-4">
      {error ? <p className="text-sm text-red-600">{error}</p> : null}

      <div className="flex flex-col gap-1">
        <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Status</label>
        <select
          value={status}
          onChange={(e) => {
            const next = e.target.value as InquiryStatus;
            setStatus(next);
            startTransition(async () => {
              const res = await updateInquiryStatus(inquiryId, next);
              if (res.error) setError(res.error);
            });
          }}
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        >
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Assigned to</label>
        <select
          value={assignedStaffId}
          onChange={(e) => {
            const next = e.target.value || null;
            setAssignedStaffId(next ?? "");
            startTransition(async () => {
              const res = await assignInquiry(inquiryId, next);
              if (res.error) setError(res.error);
            });
          }}
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        >
          <option value="">Unassigned</option>
          {staffOptions.map((s) => (
            <option key={s.id} value={s.id}>
              {s.full_name}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Family&rsquo;s language</label>
        <select
          value={language}
          onChange={(e) => {
            const next = e.target.value as PreferredLanguage;
            setLanguage(next);
            startTransition(async () => {
              const res = await updateInquiryLanguage(inquiryId, next);
              if (res.error) setError(res.error);
            });
          }}
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
        >
          {SUPPORTED_LANGUAGES.map((l) => (
            <option key={l} value={l}>
              {LANGUAGE_NAMES[l]}
            </option>
          ))}
        </select>
        <p className="text-xs text-neutral-400">
          Detected from their message. Replies (automated and manual) go out in this language.
        </p>
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-xs font-medium uppercase tracking-wide text-neutral-500">Notes</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          onBlur={() => {
            startTransition(async () => {
              const res = await updateInquiryNotes(inquiryId, notes);
              if (res.error) setError(res.error);
            });
          }}
          rows={4}
          className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
          placeholder="Internal notes (not visible to the family)"
        />
      </div>
    </div>
  );
}
