"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { requireCurrentStaff } from "@/lib/auth/current-staff";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { syncInquiryToAirtable } from "@/lib/airtable/sync";
import { translateForFamily } from "@/lib/ai/translate";
import { isPreferredLanguage } from "@/lib/i18n/language";

const statusSchema = z.enum(["new", "qualified", "scheduled", "enrolled", "lost"]);

export async function updateInquiryLanguage(inquiryId: string, language: string): Promise<{ error?: string }> {
  if (!isPreferredLanguage(language)) return { error: "Invalid language" };

  const supabase = await createServerSupabaseClient();
  const { error } = await supabase.from("inquiries").update({ preferred_language: language }).eq("id", inquiryId);
  if (error) return { error: error.message };

  revalidatePath(`/pipeline/${inquiryId}`);
  return {};
}

export async function updateInquiryStatus(inquiryId: string, status: string): Promise<{ error?: string }> {
  const parsed = statusSchema.safeParse(status);
  if (!parsed.success) return { error: "Invalid status" };

  const supabase = await createServerSupabaseClient();
  // RLS scopes this to the caller's own school — an id for another
  // school's inquiry simply matches zero rows, not an error, not a leak.
  const { error } = await supabase.from("inquiries").update({ status: parsed.data }).eq("id", inquiryId);
  if (error) return { error: error.message };

  await syncInquiryToAirtable(createAdminSupabaseClient(), inquiryId).catch((err) =>
    console.error("Airtable sync failed", err),
  );

  revalidatePath("/pipeline");
  revalidatePath(`/pipeline/${inquiryId}`);
  return {};
}

const notesSchema = z.string().max(5000);

export async function updateInquiryNotes(inquiryId: string, notes: string): Promise<{ error?: string }> {
  const parsed = notesSchema.safeParse(notes);
  if (!parsed.success) return { error: "Notes too long" };

  const supabase = await createServerSupabaseClient();
  const { error } = await supabase.from("inquiries").update({ notes: parsed.data }).eq("id", inquiryId);
  if (error) return { error: error.message };

  revalidatePath(`/pipeline/${inquiryId}`);
  return {};
}

export async function assignInquiry(inquiryId: string, staffId: string | null): Promise<{ error?: string }> {
  const supabase = await createServerSupabaseClient();
  const { error } = await supabase.from("inquiries").update({ assigned_staff_id: staffId }).eq("id", inquiryId);
  if (error) return { error: error.message };

  revalidatePath(`/pipeline/${inquiryId}`);
  return {};
}

const messageSchema = z.object({
  body: z.string().trim().min(1).max(10000),
});

export async function sendManualMessage(
  inquiryId: string,
  formData: FormData,
): Promise<{ error?: string; translated?: boolean; sentInLanguage?: string }> {
  const parsed = messageSchema.safeParse({ body: formData.get("body") });
  if (!parsed.success) return { error: "Message can't be empty" };

  const staff = await requireCurrentStaff();
  const supabase = await createServerSupabaseClient();

  const { data: inquiry, error: inquiryError } = await supabase
    .from("inquiries")
    .select("id, school_id, family_email, preferred_language")
    .eq("id", inquiryId)
    .single();
  if (inquiryError || !inquiry) return { error: "Inquiry not found" };
  if (!inquiry.family_email) return { error: "This inquiry has no email on file to reply to." };

  const { sendEmail } = await import("@/lib/email/postmark");
  const { data: school } = await supabase.from("schools").select("inbound_email").eq("id", inquiry.school_id).single();

  // The family emailed in their own language — keep the whole thread in it,
  // even when staff type their reply in English, rather than letting the
  // conversation quietly drift back to English mid-thread.
  const translated = await translateForFamily(parsed.data.body, inquiry.preferred_language);
  const outgoingBody = translated ?? parsed.data.body;

  try {
    const sent = await sendEmail({
      to: inquiry.family_email,
      subject: "Re: Your inquiry",
      textBody: outgoingBody,
      replyTo: school?.inbound_email,
    });

    const { error: insertError } = await supabase.from("messages").insert({
      school_id: inquiry.school_id,
      inquiry_id: inquiryId,
      direction: "outbound",
      channel: "email",
      from_address: school?.inbound_email ?? null,
      to_address: inquiry.family_email,
      body: outgoingBody,
    });
    if (insertError) return { error: insertError.message };

    void staff; // staff identity is captured by the audit trigger via auth.uid()
    void sent;
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Failed to send message" };
  }

  revalidatePath(`/pipeline/${inquiryId}`);
  return { translated: translated !== null, sentInLanguage: inquiry.preferred_language };
}
