"use client";

import { useActionState } from "react";
import { sendManualMessage } from "./actions";
import { LANGUAGE_NAMES } from "@/lib/i18n/language";
import type { PreferredLanguage } from "@/lib/supabase/database.types";

type State = { error?: string; translated?: boolean; sentInLanguage?: string } | null;

export function MessageForm({ inquiryId, familyLanguage }: { inquiryId: string; familyLanguage: PreferredLanguage }) {
  const [state, formAction, pending] = useActionState<State, FormData>(async (_prev, formData) => {
    const res = await sendManualMessage(inquiryId, formData);
    return res.error ? res : res;
  }, null);

  return (
    <form
      action={(formData) => {
        formAction(formData);
      }}
      className="flex flex-col gap-2 border-t border-neutral-200 p-4"
    >
      {familyLanguage !== "en" ? (
        <p className="text-xs text-neutral-500">
          Write in English — this family&rsquo;s preferred language is <strong>{LANGUAGE_NAMES[familyLanguage]}</strong>,
          so we&rsquo;ll translate before sending (or send as-is if translation isn&rsquo;t available).
        </p>
      ) : null}
      <textarea
        name="body"
        required
        rows={3}
        placeholder="Write a reply to the family…"
        className="rounded-md border border-neutral-300 px-2 py-1.5 text-sm"
      />
      {state?.error ? <p className="text-sm text-red-600">{state.error}</p> : null}
      {!state?.error && state?.translated ? (
        <p className="text-xs text-green-700">Sent, translated into {LANGUAGE_NAMES[familyLanguage]}.</p>
      ) : null}
      {!state?.error && state && !state.translated && familyLanguage !== "en" ? (
        <p className="text-xs text-amber-700">
          Sent as written (English) — translation wasn&rsquo;t available. Consider replying in{" "}
          {LANGUAGE_NAMES[familyLanguage]} directly next time.
        </p>
      ) : null}
      <button
        type="submit"
        disabled={pending}
        className="self-end rounded-md bg-neutral-900 px-3 py-1.5 text-sm font-medium text-white disabled:opacity-50"
      >
        {pending ? "Sending…" : "Send"}
      </button>
    </form>
  );
}
