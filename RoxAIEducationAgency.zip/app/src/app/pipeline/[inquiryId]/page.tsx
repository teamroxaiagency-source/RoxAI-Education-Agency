import { notFound } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { InquiryControls } from "./inquiry-controls";
import { MessageForm } from "./message-form";

export default async function InquiryDetailPage({ params }: { params: Promise<{ inquiryId: string }> }) {
  const { inquiryId } = await params;
  const supabase = await createServerSupabaseClient();

  const { data: inquiry } = await supabase.from("inquiries").select("*").eq("id", inquiryId).maybeSingle();
  if (!inquiry) notFound();

  const [{ data: messages }, { data: staffOptions }, { data: auditEntries }] = await Promise.all([
    supabase.from("messages").select("*").eq("inquiry_id", inquiryId).order("sent_at", { ascending: true }),
    supabase.from("staff_users").select("id, full_name").eq("active", true).order("full_name"),
    supabase.from("audit_log").select("*").eq("inquiry_id", inquiryId).order("created_at", { ascending: false }),
  ]);

  return (
    <div className="grid grid-cols-1 gap-4 p-6 lg:grid-cols-[2fr_1fr]">
      <div className="flex flex-col gap-4">
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h1 className="text-lg font-semibold text-neutral-900">{inquiry.family_name}</h1>
          <p className="text-sm text-neutral-500">
            {inquiry.student_name ? `${inquiry.student_name} · ` : ""}
            {inquiry.grade_requested} · {inquiry.source}
          </p>
          <p className="mt-1 text-sm text-neutral-500">
            {inquiry.family_email ?? "—"} {inquiry.family_phone ? `· ${inquiry.family_phone}` : ""}
          </p>
        </div>

        <div className="flex flex-col rounded-lg border border-neutral-200 bg-white">
          <h2 className="border-b border-neutral-200 px-4 py-3 text-sm font-semibold text-neutral-700">
            Message history
          </h2>
          <div className="flex flex-col gap-3 p-4">
            {(messages ?? []).length === 0 ? <p className="text-sm text-neutral-400">No messages yet.</p> : null}
            {(messages ?? []).map((m) => (
              <div
                key={m.id}
                className={`max-w-[85%] rounded-md p-3 text-sm ${
                  m.direction === "inbound" ? "self-start bg-neutral-100" : "self-end bg-neutral-900 text-white"
                }`}
              >
                {m.subject ? <p className="mb-1 text-xs font-semibold opacity-70">{m.subject}</p> : null}
                <p className="whitespace-pre-wrap">{m.body}</p>
                <p className="mt-1 text-[11px] opacity-60">
                  {m.direction} · {m.channel} · {new Date(m.sent_at).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
          <MessageForm inquiryId={inquiryId} familyLanguage={inquiry.preferred_language} />
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white">
          <h2 className="border-b border-neutral-200 px-4 py-3 text-sm font-semibold text-neutral-700">Audit trail</h2>
          <div className="flex flex-col divide-y divide-neutral-100">
            {(auditEntries ?? []).length === 0 ? (
              <p className="p-4 text-sm text-neutral-400">No activity recorded yet.</p>
            ) : null}
            {(auditEntries ?? []).map((entry) => (
              <div key={entry.id} className="px-4 py-2 text-xs text-neutral-500">
                <span className="font-medium text-neutral-700">{entry.action}</span> by {entry.actor_type} ·{" "}
                {new Date(entry.created_at).toLocaleString()}
              </div>
            ))}
          </div>
        </div>
      </div>

      <InquiryControls
        inquiryId={inquiryId}
        initialStatus={inquiry.status}
        initialNotes={inquiry.notes ?? ""}
        initialAssignedStaffId={inquiry.assigned_staff_id}
        initialLanguage={inquiry.preferred_language}
        staffOptions={staffOptions ?? []}
      />
    </div>
  );
}
