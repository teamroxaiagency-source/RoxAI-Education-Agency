"use client";

import { useState } from "react";
import type { OpenSlot } from "@/lib/calendar/google";
import { BOOKING_STRINGS } from "@/lib/i18n/booking-strings";
import { LANGUAGE_LOCALES } from "@/lib/i18n/language";
import type { PreferredLanguage } from "@/lib/supabase/database.types";

export function SlotPicker({
  inquiryId,
  token,
  slots,
  timezone,
  language,
}: {
  inquiryId: string;
  token: string;
  slots: OpenSlot[];
  timezone: string;
  language: PreferredLanguage;
}) {
  const [status, setStatus] = useState<"idle" | "booking" | "booked" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const strings = BOOKING_STRINGS[language];

  async function book(slot: OpenSlot) {
    setStatus("booking");
    setErrorMessage(null);
    try {
      const res = await fetch(`/api/book/${inquiryId}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token, start: slot.start, end: slot.end }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || strings.genericError);
      setStatus("booked");
    } catch (err) {
      setStatus("error");
      setErrorMessage(err instanceof Error ? err.message : strings.genericError);
    }
  }

  if (status === "booked") {
    return <p className="rounded-md bg-green-50 p-4 text-sm text-green-800">{strings.bookedConfirmation}</p>;
  }

  if (slots.length === 0) {
    return <p className="text-sm text-neutral-600">{strings.noSlots}</p>;
  }

  const formatter = new Intl.DateTimeFormat(LANGUAGE_LOCALES[language], {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: timezone,
  });

  return (
    <div className="flex flex-col gap-2">
      {errorMessage ? <p className="text-sm text-red-600">{errorMessage}</p> : null}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {slots.map((slot) => (
          <button
            key={slot.start}
            type="button"
            disabled={status === "booking"}
            onClick={() => book(slot)}
            className="rounded-md border border-neutral-300 px-3 py-2 text-sm hover:border-neutral-500 disabled:opacity-50"
          >
            {formatter.format(new Date(slot.start))}
          </button>
        ))}
      </div>
    </div>
  );
}
