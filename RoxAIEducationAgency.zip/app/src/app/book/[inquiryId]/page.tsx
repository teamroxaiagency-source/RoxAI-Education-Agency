import { verifyBookingToken } from "@/lib/booking-token";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { listOpenSlots } from "@/lib/calendar/google";
import { BOOKING_STRINGS } from "@/lib/i18n/booking-strings";
import { SlotPicker } from "./slot-picker";

export default async function BookingPage({
  params,
  searchParams,
}: {
  params: Promise<{ inquiryId: string }>;
  searchParams: Promise<{ t?: string }>;
}) {
  const { inquiryId } = await params;
  const { t } = await searchParams;

  // Language isn't known until the inquiry loads, so error copy before that
  // point falls back to English — there's no family-language signal yet.
  const en = BOOKING_STRINGS.en;

  if (!t || !verifyBookingToken(inquiryId, t)) {
    return <StatusMessage title={en.invalidLinkTitle} body={en.invalidLinkBody} />;
  }

  const db = createAdminSupabaseClient();
  const { data: inquiry } = await db
    .from("inquiries")
    .select("*, schools(id, name, timezone)")
    .eq("id", inquiryId)
    .maybeSingle();

  if (!inquiry) {
    return <StatusMessage title={en.notFoundTitle} body={en.notFoundBody} />;
  }

  const school = (inquiry as unknown as { schools: { id: string; name: string; timezone: string } }).schools;
  const strings = BOOKING_STRINGS[inquiry.preferred_language];

  if (inquiry.status === "scheduled" || inquiry.status === "enrolled") {
    return <StatusMessage title={strings.alreadyScheduledTitle} body={strings.alreadyScheduledBody(school.name)} />;
  }
  if (inquiry.status === "lost") {
    return <StatusMessage title={strings.expiredTitle} body={strings.expiredBody} />;
  }

  const slots = await listOpenSlots(db, school.id, { timezone: school.timezone });

  return (
    <div className="flex flex-1 items-center justify-center bg-neutral-50 px-4 py-10">
      <div className="w-full max-w-lg rounded-lg border border-neutral-200 bg-white p-6 shadow-sm">
        <h1 className="mb-1 text-lg font-semibold text-neutral-900">{strings.pageTitle(school.name)}</h1>
        <p className="mb-6 text-sm text-neutral-500">
          {strings.forLine(inquiry.family_name, inquiry.student_name, inquiry.grade_requested)}
        </p>
        <SlotPicker
          inquiryId={inquiryId}
          token={t}
          slots={slots}
          timezone={school.timezone}
          language={inquiry.preferred_language}
        />
      </div>
    </div>
  );
}

function StatusMessage({ title, body }: { title: string; body: string }) {
  return (
    <div className="flex flex-1 items-center justify-center bg-neutral-50 px-4 py-10">
      <div className="w-full max-w-md rounded-lg border border-neutral-200 bg-white p-6 text-center shadow-sm">
        <h1 className="mb-2 text-lg font-semibold text-neutral-900">{title}</h1>
        <p className="text-sm text-neutral-500">{body}</p>
      </div>
    </div>
  );
}
