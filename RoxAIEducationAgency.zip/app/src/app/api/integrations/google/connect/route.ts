import { NextResponse } from "next/server";
import { requireCurrentStaff } from "@/lib/auth/current-staff";
import { buildGoogleAuthUrl } from "@/lib/calendar/google";
import { encodeOAuthState } from "@/lib/oauth-state";

/**
 * Starts the per-school Google Calendar connect flow. Only a school_admin
 * may initiate this — connecting the wrong calendar (or an admissions
 * staffer's personal calendar) would leak/corrupt real tour bookings, so
 * this is deliberately more restricted than the rest of the staff view.
 */
export async function GET() {
  const staff = await requireCurrentStaff();

  if (staff.role !== "school_admin") {
    return NextResponse.json({ error: "Only a school admin can connect Google Calendar." }, { status: 403 });
  }

  const state = encodeOAuthState({ schoolId: staff.school_id, staffId: staff.id });
  return NextResponse.redirect(buildGoogleAuthUrl(state));
}
