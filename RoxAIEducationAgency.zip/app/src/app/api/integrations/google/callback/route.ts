import { NextResponse, type NextRequest } from "next/server";
import { requireCurrentStaff } from "@/lib/auth/current-staff";
import { exchangeCodeForRefreshToken, storeGoogleConnection } from "@/lib/calendar/google";
import { decodeOAuthState } from "@/lib/oauth-state";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { logAudit } from "@/lib/audit";

export async function GET(request: NextRequest) {
  const settingsUrl = new URL("/pipeline/settings", request.url);

  const code = request.nextUrl.searchParams.get("code");
  const stateParam = request.nextUrl.searchParams.get("state");
  const error = request.nextUrl.searchParams.get("error");

  if (error) {
    settingsUrl.searchParams.set("google_error", error);
    return NextResponse.redirect(settingsUrl);
  }
  if (!code || !stateParam) {
    settingsUrl.searchParams.set("google_error", "missing_code_or_state");
    return NextResponse.redirect(settingsUrl);
  }

  const state = decodeOAuthState(stateParam);
  if (!state) {
    settingsUrl.searchParams.set("google_error", "invalid_or_expired_state");
    return NextResponse.redirect(settingsUrl);
  }

  // Defense in depth beyond the signed state: the session completing the
  // OAuth round trip must still be that same staff member, school_admin,
  // right now — not just "was, ten minutes ago".
  const staff = await requireCurrentStaff();
  if (staff.id !== state.staffId || staff.school_id !== state.schoolId || staff.role !== "school_admin") {
    settingsUrl.searchParams.set("google_error", "session_mismatch");
    return NextResponse.redirect(settingsUrl);
  }

  try {
    const refreshToken = await exchangeCodeForRefreshToken(code);
    const db = createAdminSupabaseClient();
    await storeGoogleConnection(db, {
      schoolId: staff.school_id,
      refreshToken,
      connectedByStaffId: staff.id,
    });
    await logAudit(db, {
      schoolId: staff.school_id,
      actorType: "staff",
      actorId: staff.id,
      action: "google_calendar_connected",
    });
  } catch (err) {
    console.error("Google Calendar connect failed", err);
    settingsUrl.searchParams.set("google_error", "connect_failed");
    return NextResponse.redirect(settingsUrl);
  }

  settingsUrl.searchParams.set("google_connected", "1");
  return NextResponse.redirect(settingsUrl);
}
