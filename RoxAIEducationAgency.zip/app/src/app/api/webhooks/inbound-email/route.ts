import { NextResponse, type NextRequest } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { z } from "zod";
import { getServerEnv } from "@/lib/env";
import { handleInboundEmail } from "@/lib/intake/handle-inbound-email";
import type { PostmarkInboundPayload } from "@/lib/email/postmark";

// Postmark's inbound webhook is secured with HTTP Basic Auth configured on
// the webhook URL itself (Postmark > Servers > Inbound > Webhook URL:
// https://user:pass@yourapp.com/api/webhooks/inbound-email) — verified here
// so an arbitrary POST to this URL can't inject fake inquiries.
function isAuthorized(request: NextRequest): boolean {
  const env = getServerEnv();
  const header = request.headers.get("authorization") ?? "";
  const expected = `Basic ${Buffer.from(`${env.POSTMARK_INBOUND_USERNAME}:${env.POSTMARK_INBOUND_PASSWORD}`).toString("base64")}`;

  const a = Buffer.from(header);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

const payloadSchema = z.object({
  MessageID: z.string().min(1),
  From: z.string().min(1),
  FromName: z.string().optional().default(""),
  FromFull: z.object({ Email: z.string(), Name: z.string() }).partial().optional(),
  To: z.string().optional().default(""),
  OriginalRecipient: z.string().optional().default(""),
  Subject: z.string().optional().default(""),
  TextBody: z.string().optional().default(""),
  StrippedTextReply: z.string().optional(),
  Date: z.string().optional().default(""),
});

export async function POST(request: NextRequest) {
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const json = await request.json().catch(() => null);
  const parsed = payloadSchema.safeParse(json);
  if (!parsed.success) {
    // Malformed payload isn't retryable — ack it so Postmark doesn't hammer us.
    console.error("Malformed inbound email webhook payload", parsed.error.flatten());
    return NextResponse.json({ ok: true, ignored: "malformed_payload" }, { status: 200 });
  }

  const result = await handleInboundEmail(parsed.data as PostmarkInboundPayload);
  return NextResponse.json({ ok: true, result: result.outcome }, { status: 200 });
}
