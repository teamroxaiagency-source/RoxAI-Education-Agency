import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { verifyBookingToken } from "@/lib/booking-token";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
import { bookSlot } from "@/lib/calendar/google";
import { logAudit } from "@/lib/audit";
import { syncInquiryToAirtable } from "@/lib/airtable/sync";

const bodySchema = z.object({
  token: z.string().min(1),
  start: z.string().datetime(),
  end: z.string().datetime(),
});

export async function POST(request: NextRequest, { params }: { params: Promise<{ inquiryId: string }> }) {
  const { inquiryId } = await params;
  const json = await request.json().catch(() => null);
  const parsed = bodySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }

  if (!verifyBookingToken(inquiryId, parsed.data.token)) {
    return NextResponse.json({ error: "Invalid or expired booking link" }, { status: 403 });
  }

  const db = createAdminSupabaseClient();
  const { data: inquiry, error: inquiryError } = await db
    .from("inquiries")
    .select("*, schools(id, name, timezone)")
    .eq("id", inquiryId)
    .single();

  if (inquiryError || !inquiry) {
    return NextResponse.json({ error: "Inquiry not found" }, { status: 404 });
  }
  if (inquiry.status === "scheduled" || inquiry.status === "enrolled") {
    return NextResponse.json({ error: "This inquiry already has a booking." }, { status: 409 });
  }
  if (!inquiry.family_email) {
    return NextResponse.json({ error: "No email on file to send a calendar invite to." }, { status: 422 });
  }

  const school = (inquiry as unknown as { schools: { id: string; name: string; timezone: string } }).schools;

  try {
    const booked = await bookSlot(db, school.id, {
      start: parsed.data.start,
      end: parsed.data.end,
      summary: `Admissions tour/call — ${inquiry.family_name}${inquiry.student_name ? ` (${inquiry.student_name})` : ""}`,
      description: `Grade requested: ${inquiry.grade_requested}\nRoxAI inquiry: ${inquiry.id}`,
      attendeeEmail: inquiry.family_email,
    });

    await db.from("inquiries").update({ status: "scheduled" }).eq("id", inquiry.id);

    await db.from("messages").insert({
      school_id: school.id,
      inquiry_id: inquiry.id,
      direction: "outbound",
      channel: "system",
      body: `Tour/call booked for ${parsed.data.start} (calendar event ${booked.eventId}).`,
      sent_at: new Date().toISOString(),
    });

    await logAudit(db, {
      schoolId: school.id,
      inquiryId: inquiry.id,
      actorType: "agent",
      action: "tour_booked",
      detail: { start: parsed.data.start, end: parsed.data.end, calendarEventId: booked.eventId },
    });

    await syncInquiryToAirtable(db, inquiry.id).catch((err) => console.error("Airtable sync failed", err));

    return NextResponse.json({ ok: true, eventLink: booked.htmlLink });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Booking failed";
    return NextResponse.json({ error: message }, { status: 409 });
  }
}
