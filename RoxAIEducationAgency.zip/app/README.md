# RoxAI Inquiry-to-Enrollment Agent

Production pilot module: multi-tenant inquiry intake, same-day availability
replies, calendar-based tour/call booking, and an admissions staff pipeline
view. Built per `roxaiinquirytoenrollmentspec.md` — no demo/mock data, real
schema, real RLS, real integrations.

## Stack

- **Next.js 16** (App Router, TypeScript) — deployed to **Cloudflare Workers**
  via the OpenNext adapter (see "Deploying to Cloudflare Workers" below)
- **Supabase** (Postgres + Auth) — tenant isolation via native **Row-Level
  Security**, not application-layer trust (see `supabase/migrations/`)
- **Postmark** — inbound email webhook + outbound send
- **Google Calendar API** (OAuth2, per school) — real tour/call slots
- **Airtable** — RoxAI's existing lead-tracking base, kept in sync
- **Claude (Anthropic API)**, optional — grounded free-text extraction and
  reply drafting, with a deterministic fallback so the pipeline works
  end-to-end without this key too

## Language support

Built for markets beyond English-only (Kenya and beyond): the agent detects
which of **English, Swahili, or French** a family wrote in and replies in
that language — both the automated same-day reply and the booking page, and
manual staff replies too (translated before sending; staff keep writing in
English).

- Detection: `src/lib/intake/extract-inquiry-fields.ts` asks Claude to
  identify the language alongside the other extracted fields; without an
  API key, `src/lib/i18n/language.ts` falls back to a keyword-based
  heuristic. Stored on `inquiries.preferred_language`.
- Same-day reply: `src/lib/messaging/compose-reply.ts` has real,
  hand-translated deterministic templates for all three languages (not just
  English with the rest machine-translated at runtime) as the guaranteed
  fallback, plus a language-aware Claude drafting prompt when available.
- Booking page (`/book/[inquiryId]`): fully translated via
  `src/lib/i18n/booking-strings.ts`, including locale-correct date/time
  formatting (`en-US` / `sw-KE` / `fr-FR`).
- Staff can see and override the detected language in the pipeline (top
  right of an inquiry's detail page) — useful when detection guesses wrong
  on a short or mixed-language message.
- Adding a language: extend `PreferredLanguage` in
  `database.types.ts` + the migration's CHECK constraint, then add an entry
  to each of `TRANSLATIONS` (compose-reply.ts), `BOOKING_STRINGS`
  (booking-strings.ts), and `LANGUAGE_NAMES`/`LANGUAGE_LOCALES` (language.ts).

The staff pipeline dashboard itself (the Kanban board, settings, etc.)
stays English-only for now — full UI i18n for staff is a separate, larger
lift than family-facing communication and wasn't in scope here.

## Data model & tenant isolation

Six core tables from the spec — `schools`, `staff_users`, `inquiries`,
`messages`, `availability`, `audit_log` — plus `school_integrations` (holds
per-school Google/Airtable connection state; not one of the original six,
but required by them). Every tenant-scoped table:

- carries `school_id`
- has RLS **enabled and forced**
- has policies that only ever compare against the caller's own
  `school_id` (via `current_staff_school_id()`, a `security definer`
  helper reading `staff_users`) — there is no policy, anywhere, that grants
  cross-school access to the `authenticated` role

The **only** cross-tenant-capable path is the Supabase `service_role` key
(Postgres `BYPASSRLS`), used exclusively by trusted server code: the
inbound email webhook, calendar/Airtable sync, and OAuth callbacks — never
shipped to a browser or a staff session.

See `supabase/migrations/` for the full schema, constraints, triggers, and
policies, each with inline comments explaining the reasoning.

## Setup

### 1. Supabase project

```bash
npx supabase init          # if you don't already have a supabase/ CLI link
npx supabase link --project-ref <your-project-ref>
npx supabase db push       # applies supabase/migrations/*.sql
```

For local development: `npx supabase start`, then `npx supabase db reset`
(applies migrations + `supabase/seed.sql`, which creates the one fake
school — "RoxAI Staging Academy" — this project should ever contain).

Create the staging admin login:

```bash
SUPABASE_URL=http://localhost:54321 \
SUPABASE_SERVICE_ROLE_KEY=<from `supabase status`> \
STAGING_STAFF_EMAIL=you@example.com \
STAGING_STAFF_PASSWORD=<choose one> \
npm run seed:staging-staff
```

### 2. Environment

```bash
cp .env.example .env.local
```

Fill in every value — see the comments in `.env.example` for exactly where
each one comes from (Supabase dashboard, Postmark, Google Cloud Console,
Airtable). `src/lib/env.ts` validates all of this at startup with a clear
error if anything's missing or malformed, so a bad deploy fails loudly
instead of misbehaving silently.

### 3. Run

```bash
npm install
npm run dev
```

Sign in at `/login` with the staging admin credentials from step 1.

## Deploying to Cloudflare Workers

This app deploys as its own Cloudflare Worker (separate from the marketing
site's `roxai-agency` Worker at the repo root — see `../wrangler.json` and
`../.assetsignore`) via the [OpenNext adapter for
Cloudflare](https://opennext.js.org/cloudflare), not Vercel.

```bash
npx wrangler login          # once, to authenticate this machine
npm run cf:deploy           # opennextjs-cloudflare build && ... deploy
```

`npm run cf:preview` does the same build but serves it locally against the
real Workers runtime (`workerd`) instead of publishing — useful for catching
Workers-specific issues (missing bindings, unsupported APIs) before a real
deploy.

**Environment variables**: set the non-secret ones (`NEXT_PUBLIC_*`,
`POSTMARK_INBOUND_USERNAME`, `POSTMARK_FROM_EMAIL`, `GOOGLE_OAUTH_CLIENT_ID`,
`APP_BASE_URL`) as `vars` in `wrangler.jsonc` or the Cloudflare dashboard, and
the real secrets (`SUPABASE_SERVICE_ROLE_KEY`, `ENCRYPTION_KEY`,
`POSTMARK_SERVER_TOKEN`, `POSTMARK_INBOUND_PASSWORD`,
`GOOGLE_OAUTH_CLIENT_SECRET`, `AIRTABLE_API_KEY`, `ANTHROPIC_API_KEY`) via
`npx wrangler secret put <NAME>` — never in `wrangler.jsonc`, which is
committed. `src/lib/env.ts` reads them all the same way (`process.env`)
regardless of host.

### Why there's no `proxy.ts` (middleware)

Next.js 16's Proxy (the renamed middleware) always runs on the Node.js
runtime — there's no way to opt back into the Edge runtime for it — and the
Cloudflare OpenNext adapter doesn't support Node-runtime middleware yet as of
`@opennextjs/cloudflare@1.20.2` ([tracked upstream](https://github.com/cloudflare/workers-sdk/issues/13755)).
Building with a `proxy.ts` present fails outright (`Node.js middleware is
not currently supported`).

This app never actually depended on middleware for its real security
boundary: every `/pipeline/*` page already calls `requireCurrentStaff()`
(`src/lib/auth/current-staff.ts`) directly, which redirects to `/login` on
its own — middleware was doing session-cookie refresh and a redirect that's
now redundant. `/login` itself now checks for an existing session and
redirects to `/pipeline` if found, replacing the other thing middleware did.

The one real tradeoff: without middleware, a refreshed Supabase session
token can only be persisted back to the browser from a Server Action or
Route Handler (Next.js doesn't allow Server Components to set cookies) —
so a session that sits idle through nothing but plain page loads (no status
change, no message sent, no sign-in/out) refreshes less proactively than it
would with middleware in front of it. In practice any real staff activity
(which is most of what this app is for) keeps it refreshed fine. Revisit
this once the upstream issue above ships.

## Onboarding a real school

School records, grade levels, and initial `availability` capacity are
provisioned by RoxAI (not self-service) — deliberately. This is the one
config surface where a mistake (wrong tenant boundary, wrong grade list) is
expensive to unwind after real families start emailing in, and it's also
where RoxAI vets every school before it can touch the platform, rather than
running an open sign-up flow. Once a school is live:

1. Run `npm run onboard-school` (needs `SUPABASE_URL` +
   `SUPABASE_SERVICE_ROLE_KEY` in the environment). It walks through the
   school's name/slug/timezone/inbound email, each grade level and its
   capacity, and the first admin's name/email — then creates the school and
   its `availability` rows atomically (via the `onboard_school` Postgres
   function, so a mistake partway through leaves nothing half-created) and
   the first `staff_users` login (`role = 'school_admin'`), printing a
   one-time temporary password to relay to them securely. This function has
   no grant to `authenticated`/`anon` — it's only callable with the service
   role, so onboarding stays something RoxAI runs, never something a client
   session could trigger.
2. That first admin signs in, connects Google Calendar and enters the
   Airtable base/table to sync into, both from **Settings**.
3. In Postmark, point (or add a route for) the school's inbound address at
   `https://<user>:<pass>@yourapp.com/api/webhooks/inbound-email` using the
   `POSTMARK_INBOUND_USERNAME`/`PASSWORD` you configured.
4. To add more staff at that school later, create a Supabase Auth user
   (`supabase.auth.admin.createUser` or the dashboard) and a matching
   `staff_users` row with that user's `id` and `school_id` —
   `scripts/seed-staging-staff.ts` is a template for this if you want to
   script it.

No further schema changes without a migration plan once a school is live —
per the spec, this is where "we'll fix it later" isn't acceptable.

## How the core flow works

1. A family emails the school's inbound address → Postmark POSTs to
   `/api/webhooks/inbound-email` (`src/lib/intake/handle-inbound-email.ts`).
2. Fields are extracted (`src/lib/intake/extract-inquiry-fields.ts`) —
   grade is matched against the school's actual configured grade levels
   (via Claude tool-use constrained to that exact enum, or a deterministic
   heuristic fallback), never invented.
3. The inquiry is found-or-created (a DB unique index prevents duplicate
   *open* inquiries for the same family+grade — a second email just
   appends to the thread).
4. Real availability is checked (`src/lib/availability.ts`) and a same-day
   reply is composed from that real data (`src/lib/messaging/compose-reply.ts`)
   and sent via Postmark. Every fact in the reply is computed before any AI
   call — Claude, when configured, may only reword, never add a claim.
5. If space exists, the reply includes a signed booking link
   (`src/lib/booking-token.ts`) to `/book/[inquiryId]`, which shows real
   open slots pulled live from the school's connected Google Calendar
   (freebusy-checked again at booking time to prevent double-booking) and
   books on confirmation — this is the "auto-offer and book" flow from the
   spec, implemented as a booking page rather than free-text email
   negotiation, since that's more reliable and still fully automated.
6. Every automated action — inbound receipt, reply sent, tour booked — is
   recorded in `audit_log`, either by a DB trigger (staff-driven changes)
   or directly by trusted server code (agent/system actions).
7. Staff see all of it live in `/pipeline` (Kanban by status) and
   `/pipeline/[inquiryId]` (full message thread + audit trail + manual
   status/notes/assignment/reply).

## Explicitly out of scope (per spec)

- WhatsApp intake (email first; the schema already supports it —
  `inquiries.source` and `messages.channel` include `whatsapp` — but no
  channel integration is wired up yet)
- Parent Communication Assistant, Admin-Off-Their-Plate Agent, Systems
  Integration Layer
- Infrastructure for national-scale traffic — the schema/tenant model
  don't block that later, but building it now would be premature
