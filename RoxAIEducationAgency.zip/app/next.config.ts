import type { NextConfig } from "next";
import { initOpenNextCloudflareForDev } from "@opennextjs/cloudflare";

const nextConfig: NextConfig = {
  /* config options here */
};

export default nextConfig;

// Enables `npm run dev` to see Cloudflare bindings/env the same way the
// deployed Worker does. No-op in production builds.
initOpenNextCloudflareForDev();
