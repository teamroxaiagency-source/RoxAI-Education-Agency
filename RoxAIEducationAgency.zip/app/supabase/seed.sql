-- Run automatically by `supabase db reset` / `supabase start` in local dev.
-- This is the ONE fake school this project should ever contain — testing
-- happens against a fake *school*, not fake code paths. Once the pilot
-- school's real data goes in, this stays only as the sandbox for
-- pre-release testing of new changes, never mixed with real family data.

insert into public.schools (
  id, name, slug, status, timezone, inbound_email, grade_levels, contact_channels,
  term_start_date, term_end_date
) values (
  '00000000-0000-0000-0000-000000000001',
  'RoxAI Staging Academy',
  'roxai-staging-academy',
  'active',
  'America/New_York',
  'admissions+staging@mail.roxaiagency.com',
  '["Pre-K", "Kindergarten", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5"]'::jsonb,
  '{"email": true, "whatsapp": false, "web_form": false}'::jsonb,
  '2026-09-02',
  '2027-06-12'
)
on conflict (id) do nothing;

insert into public.availability (school_id, grade_level, capacity_total, seats_taken)
values
  ('00000000-0000-0000-0000-000000000001', 'Pre-K', 20, 18),
  ('00000000-0000-0000-0000-000000000001', 'Kindergarten', 24, 24),
  ('00000000-0000-0000-0000-000000000001', 'Grade 1', 24, 20),
  ('00000000-0000-0000-0000-000000000001', 'Grade 2', 24, 22),
  ('00000000-0000-0000-0000-000000000001', 'Grade 3', 22, 22),
  ('00000000-0000-0000-0000-000000000001', 'Grade 4', 22, 15),
  ('00000000-0000-0000-0000-000000000001', 'Grade 5', 22, 10)
on conflict (school_id, grade_level) do nothing;

-- staff_users needs a real auth.users row to reference (Supabase Auth
-- manages password hashing), so the staging admin account is created by
-- scripts/seed-staging-staff.mjs instead of here — run it after this seed:
--   npm run seed:staging-staff
