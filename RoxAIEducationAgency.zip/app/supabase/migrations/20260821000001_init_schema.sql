-- RoxAI Inquiry-to-Enrollment Agent — initial multi-tenant schema
--
-- Tenant isolation is enforced at the data layer via Postgres Row-Level
-- Security, not application-layer trust. Every tenant-scoped table carries
-- school_id, has RLS enabled + forced, and has zero policies that grant
-- cross-school access. The only way to read across schools is the Supabase
-- service_role key, which is never exposed to a browser/staff session and
-- is used exclusively by trusted server-side code (inbound webhooks, cron).

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- schools — tenant root
-- ---------------------------------------------------------------------------
create table public.schools (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null check (btrim(name) <> ''),
  slug                text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  status              text not null default 'trial'
                        check (status in ('trial', 'active', 'paused', 'offboarded')),
  timezone            text not null default 'UTC',
  inbound_email       text not null unique check (inbound_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  grade_levels        jsonb not null default '[]'::jsonb,
  contact_channels    jsonb not null default '{"email": true, "whatsapp": false, "web_form": false}'::jsonb,
  term_start_date     date,
  term_end_date       date,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

comment on table public.schools is 'One row per client school. Tenant boundary for every other table.';
comment on column public.schools.inbound_email is 'Dedicated inbound address this school''s families email (e.g. admissions+greenwood@mail.roxaiagency.com). Used to route inbound webhook payloads to the right tenant.';
comment on column public.schools.grade_levels is 'Array of grade level labels this school accepts inquiries for, e.g. ["Kindergarten","Grade 1"]. Validated against on inquiry intake.';

-- ---------------------------------------------------------------------------
-- staff_users — admissions staff, one row per Supabase Auth user
-- ---------------------------------------------------------------------------
create table public.staff_users (
  id          uuid primary key references auth.users (id) on delete cascade,
  school_id   uuid not null references public.schools (id) on delete restrict,
  email       text not null check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  full_name   text not null check (btrim(full_name) <> ''),
  role        text not null default 'admissions_staff'
                check (role in ('admissions_staff', 'school_admin')),
  active      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (school_id, email)
);

comment on table public.staff_users is 'School admissions staff. Scoped to exactly one school. No cross-school role exists here by design — cross-school operations happen only via the service_role key, server-side.';

-- ---------------------------------------------------------------------------
-- availability — live grade/space availability per school
-- ---------------------------------------------------------------------------
create table public.availability (
  id              uuid primary key default gen_random_uuid(),
  school_id       uuid not null references public.schools (id) on delete cascade,
  grade_level     text not null check (btrim(grade_level) <> ''),
  capacity_total  integer not null check (capacity_total >= 0),
  seats_taken     integer not null default 0 check (seats_taken >= 0),
  updated_at      timestamptz not null default now(),
  unique (school_id, grade_level),
  constraint seats_taken_within_capacity check (seats_taken <= capacity_total)
);

comment on table public.availability is 'Current open-seat count per grade per school. Checked before every automated reply so replies never promise space that doesn''t exist.';

-- ---------------------------------------------------------------------------
-- inquiries — one row per family inquiry
-- ---------------------------------------------------------------------------
create table public.inquiries (
  id                  uuid primary key default gen_random_uuid(),
  school_id           uuid not null references public.schools (id) on delete cascade,
  source              text not null check (source in ('email', 'whatsapp', 'web_form')),
  family_name         text not null check (btrim(family_name) <> ''),
  family_email        text check (family_email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  family_phone        text check (family_phone ~ '^\+[1-9]\d{6,14}$'),
  student_name        text,
  grade_requested     text not null check (btrim(grade_requested) <> ''),
  status              text not null default 'new'
                        check (status in ('new', 'qualified', 'scheduled', 'enrolled', 'lost')),
  assigned_staff_id   uuid references public.staff_users (id) on delete set null,
  notes               text,
  first_contact_at    timestamptz not null default now(),
  last_activity_at    timestamptz not null default now(),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  constraint family_contact_present check (family_email is not null or family_phone is not null)
);

comment on table public.inquiries is 'One row per family inquiry. status tracks the pipeline stage shown in the staff view.';

-- A family should not accumulate duplicate *open* inquiries for the same
-- grade at the same school just because they emailed twice — inbound intake
-- finds-and-updates the existing open row instead. Once an inquiry is
-- enrolled or lost, a fresh inquiry (e.g. a later re-application) is a new
-- row, so the partial index excludes those terminal states.
create unique index inquiries_open_dedup_email
  on public.inquiries (school_id, lower(family_email), grade_requested)
  where family_email is not null and status not in ('enrolled', 'lost');

create unique index inquiries_open_dedup_phone
  on public.inquiries (school_id, family_phone, grade_requested)
  where family_phone is not null and status not in ('enrolled', 'lost');

create index inquiries_school_status_idx on public.inquiries (school_id, status);
create index inquiries_school_last_activity_idx on public.inquiries (school_id, last_activity_at desc);

-- ---------------------------------------------------------------------------
-- messages — every inbound/outbound message tied to an inquiry
-- ---------------------------------------------------------------------------
create table public.messages (
  id                  uuid primary key default gen_random_uuid(),
  school_id           uuid not null references public.schools (id) on delete cascade,
  inquiry_id          uuid not null references public.inquiries (id) on delete cascade,
  direction           text not null check (direction in ('inbound', 'outbound')),
  channel             text not null check (channel in ('email', 'whatsapp', 'web_form', 'system')),
  from_address        text,
  to_address           text,
  subject             text,
  body                text not null,
  provider_message_id text,
  sent_at             timestamptz not null default now(),
  created_at          timestamptz not null default now()
);

comment on table public.messages is 'Full message history per inquiry, so staff see complete context rather than a summary.';

-- Idempotency for webhook redelivery (Postmark, and later WhatsApp providers,
-- retry on timeout — the same provider_message_id must never create two rows).
create unique index messages_provider_message_id_idx
  on public.messages (provider_message_id)
  where provider_message_id is not null;

create index messages_inquiry_sent_at_idx on public.messages (inquiry_id, sent_at);

-- A message's school_id must always agree with its inquiry's school_id.
-- Enforced by trigger rather than a cross-table check constraint (Postgres
-- doesn't support subqueries in CHECK) — this is the join that, if it ever
-- drifted, would be the cross-tenant leak the spec calls out as unacceptable.
create function public.messages_school_id_matches_inquiry() returns trigger
  language plpgsql as $$
begin
  if new.school_id <> (select school_id from public.inquiries where id = new.inquiry_id) then
    raise exception 'messages.school_id must match inquiries.school_id for inquiry %', new.inquiry_id;
  end if;
  return new;
end;
$$;

create trigger messages_school_id_matches_inquiry_trg
  before insert or update on public.messages
  for each row execute function public.messages_school_id_matches_inquiry();

-- ---------------------------------------------------------------------------
-- audit_log — every automated action taken
-- ---------------------------------------------------------------------------
create table public.audit_log (
  id          uuid primary key default gen_random_uuid(),
  school_id   uuid not null references public.schools (id) on delete cascade,
  inquiry_id  uuid references public.inquiries (id) on delete set null,
  actor_type  text not null check (actor_type in ('agent', 'staff', 'system')),
  actor_id    uuid references public.staff_users (id) on delete set null,
  action      text not null check (btrim(action) <> ''),
  detail      jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);

comment on table public.audit_log is 'Immutable record of every automated action (what the agent sent, when, to whom) plus staff-driven changes. Insert-only — no client update/delete policy exists.';

create index audit_log_school_created_at_idx on public.audit_log (school_id, created_at desc);
create index audit_log_inquiry_idx on public.audit_log (inquiry_id);

-- ---------------------------------------------------------------------------
-- school_integrations — per-tenant runtime integration state
--
-- Not one of the six tables in the spec's data model, but required by it:
-- the spec calls for real Google Calendar sync and Airtable sync per school,
-- and per-tenant OAuth refresh tokens are runtime data, not static secrets,
-- so they cannot live in environment config (env config is process-global,
-- not per-school). They live here, encrypted at rest at the application
-- layer (AES-256-GCM, see src/lib/crypto.ts) before ever reaching this table
-- — Postgres only ever stores ciphertext.
-- ---------------------------------------------------------------------------
create table public.school_integrations (
  school_id                       uuid primary key references public.schools (id) on delete cascade,
  google_calendar_id              text,
  google_refresh_token_ciphertext text,
  google_connected_by             uuid references public.staff_users (id) on delete set null,
  google_connected_at             timestamptz,
  airtable_base_id                text,
  airtable_table_name             text,
  updated_at                      timestamptz not null default now()
);

comment on table public.school_integrations is 'Per-school Google Calendar + Airtable connection state. Tokens are encrypted at the application layer before insert.';

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------
create function public.set_updated_at() returns trigger
  language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger schools_set_updated_at before update on public.schools
  for each row execute function public.set_updated_at();
create trigger staff_users_set_updated_at before update on public.staff_users
  for each row execute function public.set_updated_at();
create trigger availability_set_updated_at before update on public.availability
  for each row execute function public.set_updated_at();
create trigger inquiries_set_updated_at before update on public.inquiries
  for each row execute function public.set_updated_at();
create trigger school_integrations_set_updated_at before update on public.school_integrations
  for each row execute function public.set_updated_at();

-- Any activity on an inquiry (new message, status change) should bump
-- last_activity_at so the staff pipeline can sort/surface by recency.
create function public.touch_inquiry_last_activity() returns trigger
  language plpgsql as $$
begin
  update public.inquiries set last_activity_at = now() where id = new.inquiry_id;
  return new;
end;
$$;

create trigger messages_touch_inquiry_activity
  after insert on public.messages
  for each row execute function public.touch_inquiry_last_activity();
