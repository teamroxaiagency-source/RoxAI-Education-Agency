-- RoxAI operates beyond English-only markets (Kenya and beyond) — the agent
-- needs to recognize and reply in the family's own language rather than
-- assuming English, or the "same-day reply" becomes a barrier itself.

alter table public.inquiries
  add column preferred_language text not null default 'en'
    check (preferred_language in ('en', 'sw', 'fr'));

comment on column public.inquiries.preferred_language is 'Detected from the family''s inbound message (en/sw/fr), used to draft same-day replies and the booking page in their language. Staff may override.';

-- Staff can now also correct the detected language, alongside the other
-- triage fields they were already allowed to touch.
revoke update on public.inquiries from authenticated;
grant update (status, notes, assigned_staff_id, preferred_language) on public.inquiries to authenticated;
