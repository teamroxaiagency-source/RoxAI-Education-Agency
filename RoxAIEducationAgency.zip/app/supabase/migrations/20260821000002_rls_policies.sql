-- RoxAI Inquiry-to-Enrollment Agent — Row-Level Security
--
-- Every tenant-scoped table gets RLS ENABLEd *and* FORCEd (FORCE binds the
-- table owner too, not just other roles — belt and braces). No policy below
-- ever compares against anything other than the caller's own school_id, so
-- there is no cross-school SELECT/INSERT/UPDATE path for the `authenticated`
-- role even in principle. The Supabase service_role key (Postgres BYPASSRLS
-- role) is the only way to cross tenant boundaries, and it is only ever used
-- by trusted server code (inbound webhooks, calendar/Airtable sync, cron) —
-- never shipped to a browser or staff session.

-- ---------------------------------------------------------------------------
-- helpers
-- ---------------------------------------------------------------------------

-- security definer + fixed search_path: reads staff_users on the caller's
-- behalf without staff_users' own RLS recursing back into this function.
create function public.current_staff_school_id() returns uuid
  language sql stable security definer set search_path = public as $$
  select school_id from public.staff_users where id = auth.uid() and active
$$;

create function public.current_staff_role() returns text
  language sql stable security definer set search_path = public as $$
  select role from public.staff_users where id = auth.uid() and active
$$;

revoke all on function public.current_staff_school_id() from public;
revoke all on function public.current_staff_role() from public;
grant execute on function public.current_staff_school_id() to authenticated;
grant execute on function public.current_staff_role() to authenticated;

-- ---------------------------------------------------------------------------
-- schools
-- ---------------------------------------------------------------------------
alter table public.schools enable row level security;
alter table public.schools force row level security;

create policy schools_select_own on public.schools
  for select to authenticated
  using (id = public.current_staff_school_id());

-- No insert/update/delete policy for `authenticated`: school records are
-- provisioned and maintained by RoxAI via the service role only.

-- ---------------------------------------------------------------------------
-- staff_users
-- ---------------------------------------------------------------------------
alter table public.staff_users enable row level security;
alter table public.staff_users force row level security;

create policy staff_users_select_own_school on public.staff_users
  for select to authenticated
  using (school_id = public.current_staff_school_id());

-- No insert/update/delete for `authenticated`: staff accounts are
-- provisioned by RoxAI/school admins via the service role (invite flow),
-- not self-service, so a compromised staff session can't grant itself
-- another school or escalate its own role.

-- ---------------------------------------------------------------------------
-- availability
-- ---------------------------------------------------------------------------
alter table public.availability enable row level security;
alter table public.availability force row level security;

create policy availability_select_own_school on public.availability
  for select to authenticated
  using (school_id = public.current_staff_school_id());

create policy availability_update_own_school_admin on public.availability
  for update to authenticated
  using (school_id = public.current_staff_school_id() and public.current_staff_role() = 'school_admin')
  with check (school_id = public.current_staff_school_id());

-- Column-level grant: even a school_admin's UPDATE can only touch capacity
-- fields, never repoint a row at another school_id.
revoke update on public.availability from authenticated;
grant update (grade_level, capacity_total, seats_taken) on public.availability to authenticated;

-- ---------------------------------------------------------------------------
-- inquiries
-- ---------------------------------------------------------------------------
alter table public.inquiries enable row level security;
alter table public.inquiries force row level security;

create policy inquiries_select_own_school on public.inquiries
  for select to authenticated
  using (school_id = public.current_staff_school_id());

create policy inquiries_update_own_school on public.inquiries
  for update to authenticated
  using (school_id = public.current_staff_school_id())
  with check (school_id = public.current_staff_school_id());

-- Staff can triage (status, notes, assignment) but can't rewrite the
-- family's contact details, source, or move the row to another school.
revoke update on public.inquiries from authenticated;
grant update (status, notes, assigned_staff_id) on public.inquiries to authenticated;

-- No insert/delete for `authenticated`: inquiries are created exclusively
-- by inbound-channel intake (service role) so every inquiry has a real,
-- verifiable origin message in `messages`.

-- ---------------------------------------------------------------------------
-- messages
-- ---------------------------------------------------------------------------
alter table public.messages enable row level security;
alter table public.messages force row level security;

create policy messages_select_own_school on public.messages
  for select to authenticated
  using (school_id = public.current_staff_school_id());

-- Staff can send a manual outbound message from the pipeline view, scoped
-- to their own school and always tagged as outbound — inbound messages only
-- ever arrive via the service-role webhook path.
create policy messages_insert_outbound_own_school on public.messages
  for insert to authenticated
  with check (
    school_id = public.current_staff_school_id()
    and direction = 'outbound'
    and provider_message_id is null
    and school_id = (select school_id from public.inquiries where id = inquiry_id)
  );

revoke insert on public.messages from authenticated;
grant insert (school_id, inquiry_id, direction, channel, from_address, to_address, subject, body, sent_at)
  on public.messages to authenticated;

-- No update/delete for `authenticated`: message history is append-only.

-- ---------------------------------------------------------------------------
-- audit_log
-- ---------------------------------------------------------------------------
alter table public.audit_log enable row level security;
alter table public.audit_log force row level security;

create policy audit_log_select_own_school on public.audit_log
  for select to authenticated
  using (school_id = public.current_staff_school_id());

-- No insert/update/delete for `authenticated` at all: audit_log is written
-- exclusively by the triggers below (staff-driven changes) or by trusted
-- server code via the service role (agent/system actions). Client sessions
-- can read their trail but never edit it.

-- ---------------------------------------------------------------------------
-- school_integrations — staff never touch this table directly (no policies
-- means default-deny for `authenticated`); connect/sync flows always run
-- server-side under the service role.
-- ---------------------------------------------------------------------------
alter table public.school_integrations enable row level security;
alter table public.school_integrations force row level security;

-- ---------------------------------------------------------------------------
-- automatic audit trail for staff-driven changes
-- ---------------------------------------------------------------------------
create function public.audit_inquiry_status_change() returns trigger
  language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    insert into public.audit_log (school_id, inquiry_id, actor_type, actor_id, action, detail)
    values (
      new.school_id,
      new.id,
      case when auth.uid() is not null then 'staff' else 'system' end,
      auth.uid(),
      'status_changed',
      jsonb_build_object('from', old.status, 'to', new.status)
    );
  end if;
  return new;
end;
$$;

create trigger inquiries_audit_status_change
  after update on public.inquiries
  for each row execute function public.audit_inquiry_status_change();

create function public.audit_message_insert() returns trigger
  language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_log (school_id, inquiry_id, actor_type, actor_id, action, detail)
  values (
    new.school_id,
    new.inquiry_id,
    case
      when auth.uid() is not null then 'staff'
      when new.direction = 'inbound' then 'system'
      else 'agent'
    end,
    auth.uid(),
    case when new.direction = 'inbound' then 'message_received' else 'message_sent' end,
    jsonb_build_object('channel', new.channel, 'direction', new.direction)
  );
  return new;
end;
$$;

create trigger messages_audit_insert
  after insert on public.messages
  for each row execute function public.audit_message_insert();
