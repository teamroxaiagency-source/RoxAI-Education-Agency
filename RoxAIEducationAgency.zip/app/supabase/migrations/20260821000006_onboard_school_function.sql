-- Atomic school + initial availability creation, used by
-- scripts/onboard-school.ts. RoxAI-ops-only: no grant to anon/authenticated,
-- so this is reachable only via the service_role key, never from a staff
-- session — onboarding stays something RoxAI does, not something a client
-- can trigger themselves (see the "who controls onboarding" decision in
-- app/README.md).
--
-- Wrapping the school row + all its availability rows in one function call
-- means a failure partway through (bad grade data, duplicate slug) leaves
-- nothing behind — no half-created school with some but not all of its
-- grades configured.

create function public.onboard_school(
  p_name text,
  p_slug text,
  p_timezone text,
  p_inbound_email text,
  p_grade_levels jsonb, -- [{ "grade_level": "Grade 1", "capacity_total": 24 }, ...]
  p_term_start date default null,
  p_term_end date default null
) returns uuid
  language plpgsql security definer set search_path = public as $$
declare
  v_school_id uuid;
  v_grade jsonb;
begin
  if jsonb_array_length(p_grade_levels) = 0 then
    raise exception 'onboard_school requires at least one grade level';
  end if;

  insert into public.schools (
    name, slug, status, timezone, inbound_email, grade_levels, term_start_date, term_end_date
  )
  values (
    p_name,
    p_slug,
    'active',
    p_timezone,
    p_inbound_email,
    (select jsonb_agg(g ->> 'grade_level') from jsonb_array_elements(p_grade_levels) g),
    p_term_start,
    p_term_end
  )
  returning id into v_school_id;

  for v_grade in select * from jsonb_array_elements(p_grade_levels)
  loop
    insert into public.availability (school_id, grade_level, capacity_total, seats_taken)
    values (v_school_id, v_grade ->> 'grade_level', (v_grade ->> 'capacity_total')::int, 0);
  end loop;

  return v_school_id;
end;
$$;

revoke all on function public.onboard_school(text, text, text, text, jsonb, date, date) from public;
grant execute on function public.onboard_school(text, text, text, text, jsonb, date, date) to service_role;
