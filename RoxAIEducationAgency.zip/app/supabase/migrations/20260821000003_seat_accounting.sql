-- Availability must stay current automatically — a staff member forgetting
-- to decrement a seat count is exactly the kind of drift that would make
-- the agent promise space that no longer exists. So seats_taken tracks the
-- inquiries pipeline itself via trigger, not a manual staff step.

create function public.sync_seats_taken_on_enrollment() returns trigger
  language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'enrolled' and old.status is distinct from 'enrolled' then
    update public.availability
      set seats_taken = seats_taken + 1
      where school_id = new.school_id and grade_level = new.grade_requested;
  elsif old.status = 'enrolled' and new.status is distinct from 'enrolled' then
    -- Defensive: a corrected/undone enrollment frees the seat back up.
    update public.availability
      set seats_taken = greatest(seats_taken - 1, 0)
      where school_id = new.school_id and grade_level = new.grade_requested;
  end if;
  return new;
end;
$$;

create trigger inquiries_sync_seats_taken
  after update on public.inquiries
  for each row execute function public.sync_seats_taken_on_enrollment();
