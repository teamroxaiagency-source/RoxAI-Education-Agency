-- The settings page needs to show connection status ("Google Calendar:
-- connected", the configured Airtable base) without ever exposing the
-- encrypted refresh token to a staff session. Column-level GRANT means the
-- RLS policy alone isn't enough to read the ciphertext column even if a
-- future policy change loosened the row-level check.

create policy school_integrations_select_status_school_admin on public.school_integrations
  for select to authenticated
  using (school_id = public.current_staff_school_id() and public.current_staff_role() = 'school_admin');

revoke select on public.school_integrations from authenticated;
grant select (
  school_id,
  google_calendar_id,
  google_connected_by,
  google_connected_at,
  airtable_base_id,
  airtable_table_name,
  updated_at
) on public.school_integrations to authenticated;
