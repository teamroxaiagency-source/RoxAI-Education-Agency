/**
 * Creates the staging school's admin login: a real Supabase Auth user plus
 * its matching staff_users row. Run after `supabase db reset` (or against
 * any environment) has applied supabase/seed.sql:
 *
 *   SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... \
 *   STAGING_STAFF_EMAIL=you@example.com STAGING_STAFF_PASSWORD=... \
 *     npm run seed:staging-staff
 *
 * Idempotent: re-running it just resets the password and leaves the
 * staff_users row as-is.
 */
import { createClient } from "@supabase/supabase-js";

const STAGING_SCHOOL_ID = "00000000-0000-0000-0000-000000000001";

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.error(`Missing required env var: ${name}`);
    process.exit(1);
  }
  return value;
}

async function main() {
  const supabaseUrl = requireEnv("SUPABASE_URL");
  const serviceRoleKey = requireEnv("SUPABASE_SERVICE_ROLE_KEY");
  const email = process.env.STAGING_STAFF_EMAIL ?? "staging-admin@roxaiagency.com";
  const password = requireEnv("STAGING_STAFF_PASSWORD");
  const fullName = process.env.STAGING_STAFF_NAME ?? "Staging Admin";

  const admin = createClient(supabaseUrl, serviceRoleKey, { auth: { autoRefreshToken: false, persistSession: false } });

  const { data: school, error: schoolError } = await admin
    .from("schools")
    .select("id")
    .eq("id", STAGING_SCHOOL_ID)
    .maybeSingle();
  if (schoolError || !school) {
    console.error("Staging school not found — run `supabase db reset` (applies supabase/seed.sql) first.");
    process.exit(1);
  }

  let userId: string;
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
  });

  if (createError) {
    if (!createError.message.includes("already been registered")) {
      console.error("Failed to create staging auth user:", createError.message);
      process.exit(1);
    }
    const { data: list, error: listError } = await admin.auth.admin.listUsers();
    const existing = list?.users.find((u) => u.email === email);
    if (listError || !existing) {
      console.error("User exists but couldn't be looked up:", listError?.message);
      process.exit(1);
    }
    userId = existing.id;
    await admin.auth.admin.updateUserById(userId, { password });
    console.log(`Auth user already existed (${email}) — password reset.`);
  } else {
    userId = created.user.id;
    console.log(`Created auth user ${email}.`);
  }

  const { error: staffError } = await admin.from("staff_users").upsert({
    id: userId,
    school_id: STAGING_SCHOOL_ID,
    email,
    full_name: fullName,
    role: "school_admin",
    active: true,
  });
  if (staffError) {
    console.error("Failed to upsert staff_users row:", staffError.message);
    process.exit(1);
  }

  console.log(`Staging admin ready: ${email} / school_id ${STAGING_SCHOOL_ID}`);
}

main();
