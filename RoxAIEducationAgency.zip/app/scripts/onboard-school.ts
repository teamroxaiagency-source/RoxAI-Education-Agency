/**
 * RoxAI-ops-only onboarding: walks through creating a new client school —
 * the school record, its grade/capacity availability, and its first admin
 * login — in one guided run instead of hand-writing SQL. There is no
 * client-facing equivalent of this on purpose: onboarding stays something
 * RoxAI controls (vetting every school before it can touch the platform),
 * not a public sign-up flow.
 *
 * Usage:
 *   SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... npm run onboard-school
 */
import { createClient } from "@supabase/supabase-js";
import { randomBytes } from "node:crypto";
import { createInterface } from "node:readline/promises";
import { stdin, stdout } from "node:process";

const rl = createInterface({ input: stdin, output: stdout });

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.error(`Missing required env var: ${name}`);
    process.exit(1);
  }
  return value;
}

async function ask(question: string, defaultValue?: string): Promise<string> {
  const suffix = defaultValue ? ` [${defaultValue}]` : "";
  const answer = (await rl.question(`${question}${suffix}: `)).trim();
  return answer || defaultValue || "";
}

async function askRequired(question: string, validate?: (v: string) => string | null): Promise<string> {
  for (;;) {
    const answer = (await rl.question(`${question}: `)).trim();
    if (!answer) {
      console.log("  This is required.");
      continue;
    }
    const error = validate?.(answer);
    if (error) {
      console.log(`  ${error}`);
      continue;
    }
    return answer;
  }
}

async function confirm(question: string): Promise<boolean> {
  const answer = (await rl.question(`${question} (y/n): `)).trim().toLowerCase();
  return answer === "y" || answer === "yes";
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function isValidSlug(slug: string): boolean {
  return /^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug);
}

function isValidEmail(email: string): boolean {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

function isValidTimezone(tz: string): boolean {
  try {
    Intl.DateTimeFormat(undefined, { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

function isValidDate(d: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(Date.parse(d));
}

function generatePassword(): string {
  return randomBytes(12).toString("base64url");
}

interface GradeLevel {
  grade_level: string;
  capacity_total: number;
}

async function main() {
  const supabaseUrl = requireEnv("SUPABASE_URL");
  const serviceRoleKey = requireEnv("SUPABASE_SERVICE_ROLE_KEY");
  const appBaseUrl = process.env.APP_BASE_URL ?? "https://admissions.roxaiagency.com";
  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  console.log("RoxAI school onboarding\n");

  const name = await askRequired("School name");
  const suggestedSlug = slugify(name);
  let finalSlug = "";
  for (;;) {
    const candidate = (await ask("URL-safe slug", suggestedSlug)) || suggestedSlug;
    if (isValidSlug(candidate)) {
      finalSlug = candidate;
      break;
    }
    console.log("  Lowercase letters, numbers, and single hyphens only (e.g. green-valley-academy).");
  }

  const inboundEmail = await askRequired(
    `Inbound admissions email (families email this address)`,
    (v) => (isValidEmail(v) ? null : "Not a valid email address."),
  );

  const timezone = await askRequired("IANA timezone (e.g. Africa/Nairobi, America/New_York)", (v) =>
    isValidTimezone(v) ? null : "Not a recognized IANA timezone.",
  );

  const termStartRaw = await ask("Term start date (YYYY-MM-DD, optional)");
  const termStart = termStartRaw && isValidDate(termStartRaw) ? termStartRaw : null;
  const termEndRaw = await ask("Term end date (YYYY-MM-DD, optional)");
  const termEnd = termEndRaw && isValidDate(termEndRaw) ? termEndRaw : null;

  console.log("\nNow add each grade level this school accepts inquiries for.");
  const gradeLevels: GradeLevel[] = [];
  for (;;) {
    const gradeLevel = await ask(`Grade level #${gradeLevels.length + 1} (blank to finish)`);
    if (!gradeLevel) break;
    const capacityRaw = await askRequired(`  Total capacity for "${gradeLevel}"`, (v) =>
      /^\d+$/.test(v) ? null : "Enter a whole number.",
    );
    gradeLevels.push({ grade_level: gradeLevel, capacity_total: Number(capacityRaw) });
  }
  if (gradeLevels.length === 0) {
    console.error("At least one grade level is required. Aborting.");
    process.exit(1);
  }

  console.log("\nFirst admin login for this school (they can invite more staff later).");
  const adminName = await askRequired("Admin full name");
  const adminEmail = await askRequired("Admin email", (v) => (isValidEmail(v) ? null : "Not a valid email address."));

  console.log("\n--- Summary ---");
  console.log(`School:       ${name} (${finalSlug})`);
  console.log(`Timezone:     ${timezone}`);
  console.log(`Inbound:      ${inboundEmail}`);
  console.log(`Term:         ${termStart ?? "(not set)"} → ${termEnd ?? "(not set)"}`);
  console.log(`Grades:       ${gradeLevels.map((g) => `${g.grade_level} (${g.capacity_total})`).join(", ")}`);
  console.log(`First admin:  ${adminName} <${adminEmail}>`);
  console.log("");

  if (!(await confirm("Create this school?"))) {
    console.log("Aborted — nothing was created.");
    rl.close();
    return;
  }

  const { data: schoolId, error: onboardError } = await admin.rpc("onboard_school", {
    p_name: name,
    p_slug: finalSlug,
    p_timezone: timezone,
    p_inbound_email: inboundEmail,
    p_grade_levels: gradeLevels,
    p_term_start: termStart,
    p_term_end: termEnd,
  });

  if (onboardError || !schoolId) {
    console.error("\nFailed to create school:", onboardError?.message);
    console.error("Nothing was created (the school + availability insert is transactional).");
    process.exit(1);
  }

  console.log(`\nSchool created: ${schoolId}`);

  const tempPassword = generatePassword();
  const { data: authUser, error: authError } = await admin.auth.admin.createUser({
    email: adminEmail,
    password: tempPassword,
    email_confirm: true,
  });

  if (authError || !authUser?.user) {
    console.error("\nFailed to create the admin login:", authError?.message);
    console.error(`The school row (${schoolId}) was already created. Clean it up manually if you want to retry`);
    console.error(`from scratch: delete from schools where id = '${schoolId}';`);
    process.exit(1);
  }

  const { error: staffError } = await admin.from("staff_users").insert({
    id: authUser.user.id,
    school_id: schoolId,
    email: adminEmail,
    full_name: adminName,
    role: "school_admin",
    active: true,
  });

  if (staffError) {
    console.error("\nAuth user was created but the staff_users row failed:", staffError.message);
    console.error(`Fix it manually — auth user id: ${authUser.user.id}, school id: ${schoolId}`);
    process.exit(1);
  }

  console.log("\n✅ Onboarding complete.");
  console.log(`   Login URL:      ${appBaseUrl}/login`);
  console.log(`   Admin email:    ${adminEmail}`);
  console.log(`   Temp password:  ${tempPassword}`);
  console.log("   (Relay this password to the school admin over a secure channel — it's shown only once.");
  console.log("    There's no forced-reset flow yet, so ask them to change it after first login.)");
  console.log(`   Next: have them sign in and connect Google Calendar from Settings.`);

  rl.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
